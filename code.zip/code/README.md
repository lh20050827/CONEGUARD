# ConeGuard reproducibility code

## Included material

- `src/coneguard/`: DSP transformations, experimental design, statistics, certification, evaluation, and optimization modules.
- `scripts/`: corpus preparation, black-box inference, analysis, simulation, and paper-asset scripts.
- `tests/`: 25 deterministic unit tests.
- `remote/`: multi-GPU Qwen and Phi execution scripts.
- `config/`: fixed smoke-test source configuration.
- `artifacts/metadata/`: source IDs, 32/16/16 partitions, probe manifests, and integrity metadata.
- `artifacts/results/`: raw balanced responses, optimizer traces, analysis JSON files, certificate simulations, and alternative-design comparisons.

The package excludes local virtual environments, model weights, public-corpus archives, execution logs, temporary audio, and PID files.

## Environment and tests

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e '.[test,metrics]'
PYTHONPATH=src python -m pytest -q tests
```

## Reproduce the alternative-design experiment

```bash
PYTHONPATH=src python scripts/compare_design_criteria.py \
  --results-root artifacts/results \
  --output /tmp/design_criterion_comparison.json \
  --queries 24 --repetitions 1000 --seed 20260824
```

## Recompute a response-surface analysis

For example, the VoiceBank--Qwen surface can be recomputed with:

```bash
PYTHONPATH=src python scripts/analyze_pairwise_responses.py \
  --manifest artifacts/metadata/corpora/voicebank_probe24/manifest.csv \
  --responses artifacts/results/voicebank_qwen/qwen_shard_*.jsonl \
  --output /tmp/voicebank_qwen_analysis.json \
  --bootstrap-draws 2000 --efficiency-repetitions 1000 --seed 20260824
```

## Recompute optimizer summaries

```bash
PYTHONPATH=src python scripts/analyze_sequential_optimizer.py \
  --input artifacts/results/voicebank_qwen_optimizer.json \
  --output /tmp/voicebank_qwen_optimizer_analysis.json \
  --bootstrap-draws 10000 --seed 20260824
```

## Rebuild paper assets

Run this from the package root so that the output is written into the paper source directory:

```bash
python code/scripts/make_paper_assets.py \
  --results code/artifacts/results \
  --paper source/generated
```

Fresh black-box inference additionally requires the public LibriSpeech and VoiceBank+DEMAND corpora plus the referenced Qwen, Phi, and NISQAv2 model checkpoints. See `protocol.md` and the scripts under `remote/` for the fixed model revisions and execution order.

