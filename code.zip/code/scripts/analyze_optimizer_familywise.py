#!/usr/bin/env python3
"""Bonferroni sensitivity intervals across corpus-by-optimizer reward tests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--librispeech", type=Path, required=True)
    parser.add_argument("--voicebank", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=100_000)
    parser.add_argument("--family-alpha", type=float, default=0.05)
    parser.add_argument("--seed", type=int, default=20260824)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.draws < 1 or not 0.0 < args.family_alpha < 1.0:
        raise ValueError("invalid familywise configuration")
    paths = {"librispeech": args.librispeech, "voicebank": args.voicebank}
    methods = ("bayes", "random")
    comparisons = len(paths) * len(methods)
    marginal_alpha = args.family_alpha / comparisons
    rng = np.random.default_rng(args.seed)
    results = {}
    for corpus, path in paths.items():
        run = json.loads(path.read_text(encoding="utf-8"))
        for method in methods:
            values = np.asarray(
                [
                    row["reward_delta"]
                    for row in run["evaluation"]
                    if row["method"] == method
                ],
                dtype=float,
            )
            if values.size != 16:
                raise ValueError(f"{corpus}/{method} must contain 16 evaluation rows")
            indices = rng.integers(0, values.size, size=(args.draws, values.size))
            means = values[indices].mean(axis=1)
            low, high = np.quantile(
                means, [marginal_alpha / 2.0, 1.0 - marginal_alpha / 2.0]
            )
            results[f"{corpus}_{method}"] = {
                "mean": float(values.mean()),
                "ci_low": float(low),
                "ci_high": float(high),
                "positive_after_bonferroni": bool(low > 0.0),
                "n_sources": int(values.size),
            }
    payload = {
        "schema_version": 1,
        "status": "post_hoc_familywise_sensitivity_primary_intervals_remain_preregistered_95pct",
        "family_alpha": args.family_alpha,
        "comparisons": comparisons,
        "marginal_confidence": 1.0 - marginal_alpha,
        "draws": args.draws,
        "seed": args.seed,
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
