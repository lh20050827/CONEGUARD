#!/usr/bin/env python3
"""Select public clean utterances by identifiers only, with speaker round-robin."""

from __future__ import annotations

import argparse
import csv
import hashlib
from collections import defaultdict
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus", choices=("librispeech", "voicebank"), required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--count", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20260824)
    return parser.parse_args()


def keyed(value: str, seed: int) -> str:
    return hashlib.sha256(f"{seed}:{value}".encode()).hexdigest()


def speaker_id(path: Path, corpus: str) -> str:
    if corpus == "librispeech":
        return path.stem.split("-", 1)[0]
    return path.stem.split("_", 1)[0]


def select(paths: list[Path], corpus: str, count: int, seed: int) -> list[Path]:
    if count < 1:
        raise ValueError("count must be positive")
    grouped: dict[str, list[Path]] = defaultdict(list)
    for path in paths:
        grouped[speaker_id(path, corpus)].append(path)
    if not grouped:
        raise ValueError("no supported audio files found")
    speakers = sorted(grouped, key=lambda value: (keyed(value, seed), value))
    for speaker, rows in grouped.items():
        rows.sort(key=lambda path: (keyed(path.name, seed), path.name))
    selected: list[Path] = []
    offset = 0
    while len(selected) < count:
        progressed = False
        for speaker in speakers:
            rows = grouped[speaker]
            if offset < len(rows):
                selected.append(rows[offset])
                progressed = True
                if len(selected) == count:
                    break
        if not progressed:
            break
        offset += 1
    if len(selected) != count:
        raise ValueError(f"requested {count} files but only {len(selected)} are available")
    return selected


def main() -> None:
    args = parse_args()
    suffix = ".flac" if args.corpus == "librispeech" else ".wav"
    paths = sorted(path for path in args.root.rglob(f"*{suffix}") if path.is_file())
    selected = select(paths, args.corpus, args.count, args.seed)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["source_id", "audio"])
        writer.writeheader()
        for path in selected:
            writer.writerow({"source_id": path.stem, "audio": str(path.resolve())})
    print(
        f"selected={len(selected)} speakers={len({speaker_id(path, args.corpus) for path in selected})} "
        f"output={args.output}"
    )


if __name__ == "__main__":
    main()
