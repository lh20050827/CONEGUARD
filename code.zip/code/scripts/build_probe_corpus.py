#!/usr/bin/env python3
"""Build a deterministic D-optimal audio-probe corpus and held-out surface."""

from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy import signal
from scipy.stats import qmc

from coneguard.design import d_optimal_design, quadratic_features
from coneguard.dsp import apply_degradation_cone


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--n-select", type=int, default=18)
    parser.add_argument("--heldout", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20260824)
    return parser.parse_args()


def read_mono_16k(path: Path) -> np.ndarray:
    audio, sample_rate = sf.read(path, always_2d=False)
    audio = np.asarray(audio, dtype=np.float64)
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    if sample_rate != 16000:
        common = np.gcd(sample_rate, 16000)
        audio = signal.resample_poly(audio, 16000 // common, sample_rate // common)
    return audio


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    args = parse_args()
    with args.sources.open(newline="", encoding="utf-8") as handle:
        sources = list(csv.DictReader(handle))
    if not sources or any(set(row) != {"source_id", "audio"} for row in sources):
        raise ValueError("sources CSV must contain exactly source_id,audio")

    levels = np.array([0.0, 0.25, 0.5, 0.75, 1.0])
    candidates = np.array(list(itertools.product(levels, repeat=4)), dtype=float)
    candidates = candidates[np.any(candidates != 0.0, axis=1)]
    design = d_optimal_design(candidates, args.n_select)
    selected = candidates[design.indices]

    sampler = qmc.Sobol(d=4, scramble=True, seed=args.seed)
    heldout = sampler.random_base2(m=int(np.ceil(np.log2(args.heldout))))[: args.heldout]
    heldout = np.round(heldout, 8)

    args.output_root.mkdir(parents=True, exist_ok=True)
    audio_root = args.output_root / "audio"
    audio_root.mkdir(exist_ok=True)
    metadata = {
        "seed": args.seed,
        "levels": levels.tolist(),
        "candidate_count": len(candidates),
        "feature_dimension": quadratic_features(candidates).shape[1],
        "n_select": args.n_select,
        "design_indices": design.indices.tolist(),
        "design_severities": selected.tolist(),
        "heldout_severities": heldout.tolist(),
        "logdet": design.logdet,
        "rank": design.rank,
        "condition_number": design.condition_number,
        "raw_condition_number": design.raw_condition_number,
    }
    (args.output_root / "design.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    rows: list[dict[str, object]] = []
    source_hashes: dict[str, str] = {}
    for source in sources:
        source_id = source["source_id"]
        source_path = Path(source["audio"])
        if not source_path.is_file():
            raise FileNotFoundError(source_path)
        source_hashes[source_id] = file_sha256(source_path)
        audio = read_mono_16k(source_path)
        identity = apply_degradation_cone(audio, np.zeros(4), source_id=source_id)
        source_dir = audio_root / source_id
        source_dir.mkdir(exist_ok=True)
        identity_path = source_dir / "identity.wav"
        sf.write(identity_path, identity, 16000, subtype="PCM_16")
        for split, severities in (("design", selected), ("heldout", heldout)):
            for index, severity in enumerate(severities):
                probe_id = f"{split[0]}{index:03d}"
                output = apply_degradation_cone(
                    audio, severity, source_id=source_id, sample_rate=16000
                )
                output_path = source_dir / f"{probe_id}.wav"
                sf.write(output_path, output, 16000, subtype="PCM_16")
                rows.append(
                    {
                        "source_id": source_id,
                        "probe_id": probe_id,
                        "split": split,
                        "reference_audio": str(identity_path),
                        "probe_audio": str(output_path),
                        **{f"u_{axis}": float(value) for axis, value in enumerate(severity)},
                    }
                )
    manifest = args.output_root / "manifest.csv"
    with manifest.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    audio_hashes = []
    for path in sorted(audio_root.rglob("*.wav")):
        audio_hashes.append((str(path.relative_to(args.output_root)), file_sha256(path)))
    merkle_text = "".join(f"{digest}  {path}\n" for path, digest in audio_hashes)
    integrity = {
        "source_sha256": source_hashes,
        "manifest_sha256": file_sha256(manifest),
        "generated_audio_count": len(audio_hashes),
        "generated_audio_merkle_sha256": hashlib.sha256(merkle_text.encode()).hexdigest(),
        "merkle_encoding": "sha256 + two spaces + relative POSIX path + newline, sorted by path",
    }
    (args.output_root / "integrity.json").write_text(
        json.dumps(integrity, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "sources": len(sources),
                "rows": len(rows),
                "design_rows": len(sources) * len(selected),
                "heldout_rows": len(sources) * len(heldout),
                "manifest": str(manifest),
                "condition_number": design.condition_number,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
