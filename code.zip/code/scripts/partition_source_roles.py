#!/usr/bin/env python3
"""Partition an identifier-ordered source list into frozen disjoint roles."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--surface-output", type=Path, required=True)
    parser.add_argument("--optimizer-dev-output", type=Path, required=True)
    parser.add_argument("--optimizer-eval-output", type=Path, required=True)
    parser.add_argument("--surface-count", type=int, default=32)
    parser.add_argument("--optimizer-dev-count", type=int, default=16)
    parser.add_argument("--optimizer-eval-count", type=int, default=16)
    return parser.parse_args()


def write_rows(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["source_id", "audio"])
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    args = parse_args()
    counts = (args.surface_count, args.optimizer_dev_count, args.optimizer_eval_count)
    if any(count < 1 for count in counts):
        raise ValueError("all role counts must be positive")
    with args.sources.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if not rows or any(set(row) != {"source_id", "audio"} for row in rows):
        raise ValueError("sources CSV must contain exactly source_id,audio")
    if len({row["source_id"] for row in rows}) != len(rows):
        raise ValueError("source IDs must be unique")
    required = sum(counts)
    if len(rows) != required:
        raise ValueError(f"expected exactly {required} ordered sources, got {len(rows)}")

    surface_end = args.surface_count
    dev_end = surface_end + args.optimizer_dev_count
    write_rows(args.surface_output, rows[:surface_end])
    write_rows(args.optimizer_dev_output, rows[surface_end:dev_end])
    write_rows(args.optimizer_eval_output, rows[dev_end:])
    print(
        f"surface={args.surface_count} optimizer_dev={args.optimizer_dev_count} "
        f"optimizer_eval={args.optimizer_eval_count}"
    )


if __name__ == "__main__":
    main()
