#!/usr/bin/env python3
"""Post-hoc analytic-truth validation of the operational certificate code."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import numpy as np

from coneguard.certificate import certify_radius
from coneguard.design import d_optimal_design, quadratic_features


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--replicates", type=int, default=200)
    parser.add_argument("--bootstrap-draws", type=int, default=300)
    parser.add_argument("--sources", type=int, default=32)
    parser.add_argument("--seed", type=int, default=20260824)
    return parser.parse_args()


def summarize(radii: list[float], origin_pass: list[bool], true_radius: float) -> dict:
    values = np.asarray(radii, dtype=float)
    return {
        "true_radius": true_radius,
        "origin_pass_rate": float(np.mean(origin_pass)),
        "median_radius": float(np.median(values)),
        "q05_radius": float(np.quantile(values, 0.05)),
        "q95_radius": float(np.quantile(values, 0.95)),
        "containment_rate": float(np.mean(values <= true_radius)),
        "radii": radii,
        "origin_pass": origin_pass,
    }


def main() -> None:
    args = parse_args()
    if args.replicates < 1 or args.bootstrap_draws < 100 or args.sources < 2:
        raise ValueError("invalid simulation size")

    levels = np.asarray([0.0, 0.25, 0.5, 0.75, 1.0])
    candidates = np.asarray(list(itertools.product(levels, repeat=4)), dtype=float)[1:]
    design = d_optimal_design(candidates, 24)
    severities = candidates[design.indices]
    features = quadratic_features(severities)
    cases = {
        "safe": {
            "coefficients": np.asarray([-0.8] * 4 + [0.4] * 4 + [0.0] * 6),
            "true_radius": 1.0,
        },
        "boundary": {
            "coefficients": np.asarray(
                [-0.4, -0.8, -0.8, -0.8] + [0.8, 0.1, 0.1, 0.1] + [0.0] * 6
            ),
            "true_radius": 0.5,
        },
        "origin_violation": {
            "coefficients": np.asarray(
                [0.2, -0.8, -0.8, -0.8] + [0.0] * 4 + [0.0] * 6
            ),
            "true_radius": 0.0,
        },
    }

    rng = np.random.default_rng(args.seed)
    results = {}
    for case_name, case in cases.items():
        radii: list[float] = []
        origin_pass: list[bool] = []
        for replicate in range(args.replicates):
            source_coefficients = case["coefficients"] + rng.normal(
                0.0, 0.12, size=(args.sources, features.shape[1])
            )
            responses = source_coefficients @ features.T + rng.normal(
                0.0, 0.04, size=(args.sources, len(severities))
            )
            certificate = certify_radius(
                severities,
                responses,
                bootstrap_draws=args.bootstrap_draws,
                seed=args.seed + replicate,
            )
            radii.append(certificate.radius)
            origin_pass.append(bool(certificate.simultaneous_upper[0] < 0.0))
        results[case_name] = summarize(radii, origin_pass, case["true_radius"])

    payload = {
        "schema_version": 1,
        "status": "post_hoc_implementation_validation_not_confirmatory_evidence",
        "replicates": args.replicates,
        "bootstrap_draws": args.bootstrap_draws,
        "sources": args.sources,
        "source_coefficient_sd": 0.12,
        "observation_noise_sd": 0.04,
        "seed": args.seed,
        "design_indices": design.indices.tolist(),
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    compact = {
        name: {key: value for key, value in result.items() if key not in {"radii", "origin_pass"}}
        for name, result in results.items()
    }
    print(json.dumps(compact, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
