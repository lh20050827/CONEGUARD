#!/usr/bin/env python3
"""Analyze merged order-balanced JSONL responses under the frozen protocol."""

from __future__ import annotations

import argparse
import csv
import itertools
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np

from coneguard.certificate import certify_radius
from coneguard.evaluation import heldout_surface_metrics, order_antisymmetry_error
from coneguard.query_efficiency import (
    matched_query_count,
    residual_noise_scale,
    simulate_query_efficiency,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--responses", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--bootstrap-draws", type=int, default=2000)
    parser.add_argument("--efficiency-repetitions", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260824)
    return parser.parse_args()


def load_jsonl(paths: list[Path]) -> dict[tuple[str, str], dict]:
    records: dict[tuple[str, str], dict] = {}
    for path in paths:
        for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            row = json.loads(line)
            key = (str(row["source_id"]), str(row["probe_id"]))
            if key in records:
                raise ValueError(f"duplicate response {key} in {path}:{line_number}")
            records[key] = row
    return records


def response_matrix(
    manifest: list[dict], records: dict[tuple[str, str], dict], split: str
) -> tuple[list[str], list[str], np.ndarray, np.ndarray]:
    rows = [row for row in manifest if row["split"] == split]
    sources = sorted({row["source_id"] for row in rows})
    probes = sorted({row["probe_id"] for row in rows})
    lookup = {(row["source_id"], row["probe_id"]): row for row in rows}
    severities = np.empty((len(probes), 4), dtype=float)
    responses = np.empty((len(sources), len(probes)), dtype=float)
    for probe_index, probe in enumerate(probes):
        first = lookup[(sources[0], probe)]
        severities[probe_index] = [float(first[f"u_{axis}"]) for axis in range(4)]
        for source_index, source in enumerate(sources):
            manifest_row = lookup.get((source, probe))
            if manifest_row is None:
                raise ValueError(f"manifest lacks {(source, probe)}")
            observed = [float(manifest_row[f"u_{axis}"]) for axis in range(4)]
            if not np.array_equal(severities[probe_index], observed):
                raise ValueError(f"severity mismatch for probe {probe}")
            record = records.get((source, probe))
            if record is None:
                raise ValueError(f"response lacks {(source, probe)}")
            responses[source_index, probe_index] = float(record["reward_delta_probe_minus_reference"])
    return sources, probes, severities, responses


def main() -> None:
    args = parse_args()
    with args.manifest.open(newline="", encoding="utf-8") as handle:
        manifest = list(csv.DictReader(handle))
    records = load_jsonl(args.responses)
    manifest_keys = {(row["source_id"], row["probe_id"]) for row in manifest}
    extra = sorted(set(records) - manifest_keys)
    if extra:
        raise ValueError(f"responses contain {len(extra)} keys absent from manifest")

    sources, design_probes, design_u, design_y = response_matrix(manifest, records, "design")
    heldout_sources, heldout_probes, heldout_u, heldout_y = response_matrix(
        manifest, records, "heldout"
    )
    if sources != heldout_sources:
        raise ValueError("design and held-out source IDs differ")

    required = len(manifest_keys)
    finite_records = [
        row
        for key, row in records.items()
        if key in manifest_keys
        and np.isfinite(float(row["margin_reference_as_a"]))
        and np.isfinite(float(row["margin_probe_as_a"]))
    ]
    finite_fraction = len(finite_records) / required
    antisymmetry = order_antisymmetry_error(
        np.asarray([float(row["margin_reference_as_a"]) for row in finite_records]),
        np.asarray([float(row["margin_probe_as_a"]) for row in finite_records]),
    )
    certificate = certify_radius(
        design_u,
        design_y,
        bootstrap_draws=args.bootstrap_draws,
        seed=args.seed,
    )
    heldout = heldout_surface_metrics(design_u, design_y, heldout_u, heldout_y)
    levels = np.asarray([0.0, 0.25, 0.5, 0.75, 1.0])
    candidates = np.asarray(list(itertools.product(levels, repeat=4)), dtype=float)
    candidates = candidates[np.any(candidates != 0.0, axis=1)]
    noise_scale = residual_noise_scale(
        design_u, design_y, certificate.point_coefficients
    )
    efficiency = simulate_query_efficiency(
        candidates,
        certificate.point_coefficients,
        noise_scale=noise_scale,
        design_sizes=(14, 18, 24, 28, 32, 36, 40, 44, 48, 64),
        repetitions=args.efficiency_repetitions,
        seed=args.seed,
    )
    matched = matched_query_count(efficiency)
    result = {
        "schema_version": 1,
        "sources": sources,
        "n_sources": len(sources),
        "n_design_probes": len(design_probes),
        "n_heldout_probes": len(heldout_probes),
        "required_responses": required,
        "observed_responses": len(records),
        "finite_fraction": finite_fraction,
        "finite_gate_pass": bool(finite_fraction >= 0.99),
        "order_antisymmetry_median_abs_error": float(np.median(antisymmetry)),
        "order_gate_pass": bool(np.median(antisymmetry) <= 0.25),
        "v2_balanced_format_gate_pass": bool(finite_fraction >= 0.99),
        "certified_radius": certificate.radius,
        "heldout": asdict(heldout),
        "v2_mean_surface_gate_pass": bool(heldout.mean_r2 >= 0.60),
        "query_efficiency": {
            "repetitions": args.efficiency_repetitions,
            "residual_noise_scale": noise_scale,
            "rows": [asdict(row) for row in efficiency],
            "matched_query_count": asdict(matched),
            "matched_query_reduction_gate_pass": bool(
                matched.query_reduction is not None and matched.query_reduction >= 0.30
            ),
            "interpretation": "parametric simulation around the frozen 24-probe surface",
        },
        "point_coefficients": certificate.point_coefficients.tolist(),
        "certificate_curve": {
            "radii": certificate.radii.tolist(),
            "simultaneous_upper": certificate.simultaneous_upper.tolist(),
        },
        "bootstrap": {
            "draws": args.bootstrap_draws,
            "seed": args.seed,
            "alpha": 0.05,
            "source_clustered": True,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
