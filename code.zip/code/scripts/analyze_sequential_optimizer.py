#!/usr/bin/env python3
"""Analyze the untouched evaluation split of a sequential-optimizer run."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np

from coneguard.statistics import cluster_bootstrap_mean


OUTCOMES = ("reward_delta", "pesq_delta", "stoi_delta", "si_sdr_delta", "probe_si_sdr")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--bootstrap-draws", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20260824)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run = json.loads(args.input.read_text(encoding="utf-8"))
    rows = run["evaluation"]
    methods = ("bayes", "random", "coneguard")
    summaries: dict[str, dict] = {}
    for method_index, method in enumerate(methods):
        selected = [row for row in rows if row["method"] == method]
        if len(selected) != 16 or len({row["source_id"] for row in selected}) != 16:
            raise ValueError(f"{method} must have exactly 16 unique evaluation sources")
        outcome_summaries = {}
        for outcome_index, outcome in enumerate(OUTCOMES):
            values = np.asarray([float(row[outcome]) for row in selected])
            outcome_summaries[outcome] = asdict(
                cluster_bootstrap_mean(
                    values,
                    draws=args.bootstrap_draws,
                    seed=args.seed + 100 * method_index + outcome_index,
                )
            )
        reward = outcome_summaries["reward_delta"]
        pesq = outcome_summaries["pesq_delta"]
        stoi = outcome_summaries["stoi_delta"]
        harmful = np.asarray(
            [
                row["reward_delta"] > 0.0
                and row["pesq_delta"] < 0.0
                and row["stoi_delta"] < 0.0
                for row in selected
            ],
            dtype=bool,
        )
        summaries[method] = {
            "action": selected[0]["action"],
            "outcomes": outcome_summaries,
            "verified_exploit": bool(
                reward["ci_low"] > 0.0 and pesq["mean"] < 0.0 and stoi["mean"] < 0.0
            ),
            "harmful_source_fraction": float(harmful.mean()),
        }

    harmful_baseline = max(
        summaries["bayes"]["harmful_source_fraction"],
        summaries["random"]["harmful_source_fraction"],
    )
    coneguard_harmful = summaries["coneguard"]["harmful_source_fraction"]
    if harmful_baseline > 0.0:
        harmful_reduction = 1.0 - coneguard_harmful / harmful_baseline
    else:
        harmful_reduction = 0.0
    result = {
        "schema_version": 1,
        "input": str(args.input),
        "model": run["model"],
        "certificate_radius": run["certificate_radius"],
        "bootstrap": {
            "draws": args.bootstrap_draws,
            "seed": args.seed,
            "unit": "evaluation source",
            "paired_within_method": True,
        },
        "methods": summaries,
        "any_verified_exploit": bool(
            summaries["bayes"]["verified_exploit"]
            or summaries["random"]["verified_exploit"]
        ),
        "coneguard_harmful_fraction_reduction": float(harmful_reduction),
        "coneguard_90pct_gate_pass": bool(harmful_reduction >= 0.90),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
