#!/usr/bin/env python3
"""Compare deterministic 24-query designs around the six fitted surfaces."""

from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import asdict
from pathlib import Path

import numpy as np

from coneguard.design import d_optimal_design, quadratic_features
from coneguard.design_baselines import (
    exchange_optimal_design,
    maximin_design,
    simulate_fixed_designs,
    snapped_sobol_design,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--queries", type=int, default=24)
    parser.add_argument("--repetitions", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260824)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    levels = (0.0, 0.25, 0.5, 0.75, 1.0)
    candidates = np.asarray(list(itertools.product(levels, repeat=4)), dtype=float)[
        1:
    ]
    designs = {
        "d_opt": d_optimal_design(candidates, args.queries).indices,
        "a_opt": exchange_optimal_design(
            candidates, args.queries, kind="a_opt"
        ),
        "g_opt": exchange_optimal_design(
            candidates, args.queries, kind="g_opt"
        ),
        "maximin": maximin_design(candidates, args.queries),
        "sobol": snapped_sobol_design(
            candidates, args.queries, seed=args.seed
        ),
    }
    raw_features = quadratic_features(candidates)
    scale = raw_features.std(axis=0)
    scale[scale < 1e-12] = 1.0
    design_metadata = {
        name: {
            "indices": indices.tolist(),
            "rank": int(np.linalg.matrix_rank(raw_features[indices])),
            "standardized_condition_number": float(
                np.linalg.cond(raw_features[indices] / scale)
            ),
        }
        for name, indices in designs.items()
    }

    surfaces: dict[str, object] = {}
    for corpus in ("librispeech", "voicebank"):
        for reward in ("nisqa", "qwen", "phi"):
            name = f"{corpus}_{reward}"
            analysis_path = args.results_root / f"{name}_analysis.json"
            analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
            rows = simulate_fixed_designs(
                candidates,
                np.asarray(analysis["point_coefficients"], dtype=float),
                designs,
                noise_scale=float(
                    analysis["query_efficiency"]["residual_noise_scale"]
                ),
                repetitions=args.repetitions,
                seed=args.seed,
            )
            surfaces[name] = {row.name: asdict(row) for row in rows}

    relative_a_to_d = [
        surfaces[name]["a_opt"]["median_error"]
        / surfaces[name]["d_opt"]["median_error"]
        for name in surfaces
    ]
    result = {
        "schema_version": 1,
        "study_type": "offline parametric design comparison",
        "model_calls": 0,
        "queries_per_design": args.queries,
        "repetitions_per_surface": args.repetitions,
        "seed": args.seed,
        "candidate_count": len(candidates),
        "designs": design_metadata,
        "surfaces": surfaces,
        "summary": {
            "a_opt_error_reduction_vs_d_opt_range": [
                float(1.0 - max(relative_a_to_d)),
                float(1.0 - min(relative_a_to_d)),
            ],
            "d_opt_beats_g_opt_on_all_surfaces": all(
                surfaces[name]["d_opt"]["median_error"]
                < surfaces[name]["g_opt"]["median_error"]
                for name in surfaces
            ),
            "d_opt_beats_maximin_on_all_surfaces": all(
                surfaces[name]["d_opt"]["median_error"]
                < surfaces[name]["maximin"]["median_error"]
                for name in surfaces
            ),
            "d_opt_beats_sobol_on_all_surfaces": all(
                surfaces[name]["d_opt"]["median_error"]
                < surfaces[name]["sobol"]["median_error"]
                for name in surfaces
            ),
            "d_opt_beats_random_on_all_surfaces": all(
                surfaces[name]["d_opt"]["median_error"]
                < surfaces[name]["random"]["median_error"]
                for name in surfaces
            ),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result["summary"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
