#!/usr/bin/env python3
"""Measure order-balanced Phi-4-multimodal A/B next-token margins."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import soundfile as sf
import torch
import transformers
from transformers import AutoModelForCausalLM, AutoProcessor


INSTRUCTION = (
    "You are an expert listener comparing overall speech quality. Consider noise, "
    "coloration, clipping, and temporal dropouts. Ignore the words, speaker identity, "
    "and presentation order. Which audio has better overall listening quality? "
    "Output exactly one letter: A or B."
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--num-shards", type=int, default=1)
    parser.add_argument("--max-rows", type=int)
    return parser.parse_args()


def token_id(processor, label: str) -> int:
    ids = processor.tokenizer.encode(label, add_special_tokens=False)
    if len(ids) != 1:
        raise RuntimeError(f"label {label!r} is not one token: {ids}")
    return int(ids[0])


def waveform(path: Path) -> tuple[object, int]:
    audio, sample_rate = sf.read(path, dtype="float32", always_2d=False)
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    if sample_rate != 16000:
        raise ValueError(f"Phi input must be 16 kHz, got {sample_rate}: {path}")
    return audio, sample_rate


def move_inputs(inputs, device: torch.device) -> dict:
    moved = {}
    for key, value in inputs.items():
        if not isinstance(value, torch.Tensor):
            moved[key] = value
        elif torch.is_floating_point(value):
            moved[key] = value.to(device=device, dtype=torch.float16)
        else:
            moved[key] = value.to(device=device)
    return moved


def next_token_margin(model, processor, audio_a: Path, audio_b: Path, a_id: int, b_id: int) -> float:
    text = (
        "<|user|><|audio_1|><|audio_2|>Audio A is the first clip and Audio B is "
        f"the second clip. {INSTRUCTION}<|end|><|assistant|>"
    )
    batch = processor(
        text=text,
        audios=[waveform(audio_a), waveform(audio_b)],
        return_tensors="pt",
    )
    inputs = move_inputs(batch, model.device)
    with torch.inference_mode():
        outputs = model(**inputs, use_cache=False, return_dict=True)
    logits = outputs.logits[0, -1].float()
    margin = logits[a_id] - logits[b_id]
    if not torch.isfinite(margin):
        raise RuntimeError("non-finite A/B margin")
    return float(margin.cpu())


def main() -> None:
    args = parse_args()
    if args.num_shards < 1 or not 0 <= args.shard_index < args.num_shards:
        raise ValueError("invalid shard configuration")
    with args.manifest.open(newline="", encoding="utf-8") as handle:
        all_rows = list(csv.DictReader(handle))
    rows = [row for index, row in enumerate(all_rows) if index % args.num_shards == args.shard_index]
    if args.max_rows is not None:
        rows = rows[: args.max_rows]
    args.output.parent.mkdir(parents=True, exist_ok=True)

    processor = AutoProcessor.from_pretrained(str(args.model), trust_remote_code=True)
    a_id, b_id = token_id(processor, "A"), token_id(processor, "B")
    model = AutoModelForCausalLM.from_pretrained(
        str(args.model),
        device_map="cuda",
        torch_dtype=torch.float16,
        trust_remote_code=True,
        # The official model card requires eager attention on pre-Ampere GPUs.
        _attn_implementation="eager",
    ).eval()

    completed: set[tuple[str, str]] = set()
    if args.output.exists():
        for line in args.output.read_text(encoding="utf-8").splitlines():
            record = json.loads(line)
            completed.add((record["source_id"], record["probe_id"]))
    metadata = {
        "model": str(args.model),
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "dtype": "float16",
        "attention": "eager",
        "shard_index": args.shard_index,
        "num_shards": args.num_shards,
        "token_ids": {"A": a_id, "B": b_id},
        "instruction": INSTRUCTION,
        "prompt_sha256": hashlib.sha256(INSTRUCTION.encode()).hexdigest(),
    }
    args.output.with_suffix(args.output.suffix + ".meta.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    written = len(completed)
    with args.output.open("a", encoding="utf-8") as sink:
        for row in rows:
            key = (row["source_id"], row["probe_id"])
            if key in completed:
                continue
            reference, probe = Path(row["reference_audio"]), Path(row["probe_audio"])
            if not reference.is_file() or not probe.is_file():
                raise FileNotFoundError(reference if not reference.is_file() else probe)
            reference_first = next_token_margin(model, processor, reference, probe, a_id, b_id)
            probe_first = next_token_margin(model, processor, probe, reference, a_id, b_id)
            oriented = 0.5 * (reference_first - probe_first)
            record = {
                **row,
                "margin_reference_as_a": reference_first,
                "margin_probe_as_a": probe_first,
                "reference_preference_margin": oriented,
                "reward_delta_probe_minus_reference": -oriented,
                "model": str(args.model),
                "dtype": "float16",
            }
            sink.write(json.dumps(record, ensure_ascii=False) + "\n")
            sink.flush()
            written += 1
            print(f"[{written}/{len(rows)}] {row['source_id']} {row['probe_id']} delta={-oriented:.4f}", flush=True)


if __name__ == "__main__":
    main()
