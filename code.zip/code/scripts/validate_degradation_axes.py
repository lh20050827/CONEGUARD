#!/usr/bin/env python3
"""Fail closed unless every maximum pure-axis edit reduces SI-SDR."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from coneguard.dsp import apply_degradation_cone
from coneguard.reference_metrics import si_sdr

from build_probe_corpus import read_mono_16k


AXES = ("noise", "bandlimit", "dropout", "clipping")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sources", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--minimum-drop-db", type=float, default=0.5)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    with args.sources.open(newline="", encoding="utf-8") as handle:
        sources = list(csv.DictReader(handle))
    if not sources or any(set(row) != {"source_id", "audio"} for row in sources):
        raise ValueError("sources CSV must contain exactly source_id,audio")
    per_source: list[dict] = []
    for source in sources:
        audio = read_mono_16k(Path(source["audio"]))
        identity = apply_degradation_cone(audio, np.zeros(4), source_id=source["source_id"])
        identity_score = si_sdr(identity, identity)
        axis_scores = {}
        for axis, name in enumerate(AXES):
            severity = np.zeros(4)
            severity[axis] = 1.0
            degraded = apply_degradation_cone(audio, severity, source_id=source["source_id"])
            score = si_sdr(identity, degraded)
            axis_scores[name] = {
                "si_sdr_db": score,
                "drop_from_identity_db": identity_score - score,
            }
        per_source.append(
            {
                "source_id": source["source_id"],
                "identity_si_sdr_db": identity_score,
                "axes": axis_scores,
            }
        )
    summary = {}
    for name in AXES:
        drops = np.asarray([row["axes"][name]["drop_from_identity_db"] for row in per_source])
        summary[name] = {
            "minimum_drop_db": float(drops.min()),
            "median_drop_db": float(np.median(drops)),
            "pass": bool(drops.min() >= args.minimum_drop_db),
        }
    result = {
        "metric": "SI-SDR",
        "minimum_required_drop_db": args.minimum_drop_db,
        "all_axes_pass": all(row["pass"] for row in summary.values()),
        "summary": summary,
        "per_source": per_source,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result["summary"], indent=2, sort_keys=True))
    if not result["all_axes_pass"]:
        raise SystemExit("one or more degradation axes failed the SI-SDR gate")


if __name__ == "__main__":
    main()
