#!/usr/bin/env python3
"""Run the preregistered sequential optimizer with eight resident Qwen workers."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import os
from pathlib import Path

import numpy as np
import soundfile as sf
import torch
import torch.distributed as dist
import transformers
from pesq import pesq
from pystoi import stoi
from scipy import signal
from transformers import (
    Qwen2_5OmniConfig,
    Qwen2_5OmniProcessor,
    Qwen2_5OmniThinkerForConditionalGeneration,
)

from coneguard.dsp import apply_degradation_cone
from coneguard.optimization import (
    QUERY_BUDGET,
    next_bayes_action,
    random_actions,
    select_incumbent,
    sobol_candidate_pool,
)
from coneguard.reference_metrics import si_sdr

from run_qwen_pairwise_margin import (
    SYSTEM_PROMPT,
    USER_QUESTION,
    next_token_margin,
    token_id,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--development-sources", type=Path, required=True)
    parser.add_argument("--evaluation-sources", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--certificate-radius", type=float, required=True)
    return parser.parse_args()


def read_sources(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 16 or any(set(row) != {"source_id", "audio"} for row in rows):
        raise ValueError(f"{path} must contain exactly 16 source_id,audio rows")
    if len({row["source_id"] for row in rows}) != 16:
        raise ValueError(f"{path} contains duplicate source IDs")
    return rows


def read_mono_16k(path: Path) -> np.ndarray:
    audio, sample_rate = sf.read(path, always_2d=False)
    audio = np.asarray(audio, dtype=np.float64)
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    if sample_rate != 16000:
        common = np.gcd(sample_rate, 16000)
        audio = signal.resample_poly(audio, 16000 // common, sample_rate // common)
    return audio


def atomic_json(path: Path, payload: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


class DistributedEvaluator:
    def __init__(
        self,
        *,
        rows: list[dict[str, str]],
        split: str,
        work_root: Path,
        model,
        processor,
        a_id: int,
        b_id: int,
        rank: int,
        world_size: int,
    ) -> None:
        self.rows = rows
        self.split = split
        self.model = model
        self.processor = processor
        self.a_id = a_id
        self.b_id = b_id
        self.rank = rank
        self.world_size = world_size
        self.local: dict[int, tuple[str, np.ndarray, np.ndarray, Path]] = {}
        split_root = work_root / split
        split_root.mkdir(parents=True, exist_ok=True)
        for index, row in enumerate(rows):
            if index % world_size != rank:
                continue
            source_id = row["source_id"]
            original = read_mono_16k(Path(row["audio"]))
            identity = apply_degradation_cone(
                original, np.zeros(4), source_id=source_id, sample_rate=16000
            )
            source_root = split_root / source_id
            source_root.mkdir(parents=True, exist_ok=True)
            identity_path = source_root / "identity.wav"
            sf.write(identity_path, identity, 16000, subtype="PCM_16")
            self.local[index] = (
                source_id,
                np.asarray(original),
                np.asarray(identity),
                identity_path,
            )

    def evaluate(self, action: np.ndarray, tag: str, *, metrics: bool) -> np.ndarray:
        action = np.asarray(action, dtype=np.float64)
        if action.shape != (4,):
            raise ValueError("action must contain four severities")
        columns = 7 if metrics else 3
        values = np.zeros((len(self.rows), columns), dtype=np.float64)
        identity_action = bool(np.all(action == 0.0))
        for index, (source_id, original, identity, identity_path) in self.local.items():
            if identity_action:
                reference_first = probe_first = reward = 0.0
                probe = identity
            else:
                probe = apply_degradation_cone(
                    original, action, source_id=source_id, sample_rate=16000
                )
                probe_path = identity_path.parent / f"{tag}.wav"
                sf.write(probe_path, probe, 16000, subtype="PCM_16")
                reference_first = next_token_margin(
                    self.model,
                    self.processor,
                    identity_path,
                    probe_path,
                    self.a_id,
                    self.b_id,
                )
                probe_first = next_token_margin(
                    self.model,
                    self.processor,
                    probe_path,
                    identity_path,
                    self.a_id,
                    self.b_id,
                )
                reward = -0.5 * (reference_first - probe_first)
            values[index, :3] = [reward, reference_first, probe_first]
            if metrics:
                baseline_pesq = float(pesq(16000, identity, identity, "wb"))
                probe_pesq = float(pesq(16000, identity, probe, "wb"))
                baseline_stoi = float(stoi(identity, identity, 16000, extended=False))
                probe_stoi = float(stoi(identity, probe, 16000, extended=False))
                baseline_si_sdr = si_sdr(identity, identity)
                probe_si_sdr = si_sdr(identity, probe)
                values[index, 3:] = [
                    probe_pesq - baseline_pesq,
                    probe_stoi - baseline_stoi,
                    probe_si_sdr - baseline_si_sdr,
                    probe_si_sdr,
                ]
        tensor = torch.as_tensor(
            values,
            dtype=torch.float64,
            device=torch.device("cuda", torch.cuda.current_device()),
        )
        dist.all_reduce(tensor, op=dist.ReduceOp.SUM)
        return tensor.cpu().numpy()


def development_records(state: dict, method: str) -> list[dict]:
    return [row for row in state["development"] if row["method"] == method]


def main() -> None:
    args = parse_args()
    logging.getLogger().setLevel(logging.ERROR)
    if not 0.0 <= args.certificate_radius <= 1.0:
        raise ValueError("certificate radius must lie in [0,1]")
    dist.init_process_group(backend="nccl")
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    local_rank = int(os.environ["LOCAL_RANK"])
    if world_size != 8:
        raise RuntimeError(f"the frozen stress test requires 8 processes, got {world_size}")
    torch.cuda.set_device(local_rank)
    device = torch.device("cuda", local_rank)
    args.output.parent.mkdir(parents=True, exist_ok=True)

    development = read_sources(args.development_sources)
    evaluation = read_sources(args.evaluation_sources)
    if {row["source_id"] for row in development} & {row["source_id"] for row in evaluation}:
        raise ValueError("development and evaluation source IDs overlap")

    processor = Qwen2_5OmniProcessor.from_pretrained(str(args.model), use_fast=False)
    a_id, b_id = token_id(processor, "A"), token_id(processor, "B")
    full_config = Qwen2_5OmniConfig.from_pretrained(str(args.model))
    model = Qwen2_5OmniThinkerForConditionalGeneration.from_pretrained(
        str(args.model),
        config=full_config.thinker_config,
        torch_dtype=torch.float16,
        device_map={"": local_rank},
        attn_implementation="sdpa",
    ).eval()

    if rank == 0 and args.output.exists():
        state = json.loads(args.output.read_text(encoding="utf-8"))
    else:
        state = {
            "schema_version": 1,
            "model": str(args.model),
            "model_revision": "ae9e1690543ffd5c0221dc27f79834d0294cba00",
            "torch": torch.__version__,
            "transformers": transformers.__version__,
            "dtype": "float16",
            "world_size": world_size,
            "certificate_radius": args.certificate_radius,
            "development_source_ids": [row["source_id"] for row in development],
            "evaluation_source_ids": [row["source_id"] for row in evaluation],
            "prompt_sha256": hashlib.sha256(
                (SYSTEM_PROMPT + "\n" + USER_QUESTION).encode()
            ).hexdigest(),
            "development": [],
            "incumbents": {},
            "evaluation": [],
        }
    container = [state if rank == 0 else None]
    dist.broadcast_object_list(container, src=0)
    state = container[0]

    work_root = args.output.parent / f".{args.output.stem}_audio"
    dev_evaluator = DistributedEvaluator(
        rows=development,
        split="development",
        work_root=work_root,
        model=model,
        processor=processor,
        a_id=a_id,
        b_id=b_id,
        rank=rank,
        world_size=world_size,
    )
    eval_evaluator = DistributedEvaluator(
        rows=evaluation,
        split="evaluation",
        work_root=work_root,
        model=model,
        processor=processor,
        a_id=a_id,
        b_id=b_id,
        rank=rank,
        world_size=world_size,
    )

    method_radii = {"bayes": 1.0, "random": 1.0}
    if args.certificate_radius > 0.0:
        method_radii["coneguard"] = args.certificate_radius
    sealed_random = random_actions()
    for method, radius in method_radii.items():
        records = development_records(state, method)
        while len(records) < QUERY_BUDGET:
            action_tensor = torch.zeros(4, dtype=torch.float64, device=device)
            pool_index = -1
            if rank == 0:
                if method == "random":
                    action = sealed_random[len(records)]
                else:
                    actions = np.asarray([row["action"] for row in records]).reshape(-1, 4)
                    rewards = np.asarray([row["mean_reward"] for row in records])
                    pool = sobol_candidate_pool(radius=radius)
                    pool_index, action = next_bayes_action(
                        actions, rewards, radius=radius, pool=pool
                    )
                action_tensor.copy_(torch.as_tensor(action, dtype=torch.float64, device=device))
            dist.broadcast(action_tensor, src=0)
            action = action_tensor.cpu().numpy()
            values = dev_evaluator.evaluate(
                action, f"{method}_{len(records):03d}", metrics=False
            )
            if rank == 0:
                record = {
                    "method": method,
                    "query_index": len(records),
                    "pool_index": pool_index if method != "random" else None,
                    "action": action.tolist(),
                    "mean_reward": float(values[:, 0].mean()),
                    "source_rewards": values[:, 0].tolist(),
                    "margin_reference_as_a": values[:, 1].tolist(),
                    "margin_probe_as_a": values[:, 2].tolist(),
                }
                state["development"].append(record)
                records.append(record)
                atomic_json(args.output, state)
                print(
                    f"{method} query={len(records):02d}/{QUERY_BUDGET} "
                    f"reward={record['mean_reward']:+.6f} action={action.tolist()}",
                    flush=True,
                )
            else:
                # Keep every rank on the same sequential loop iteration. Only
                # rank zero needs the full trace to choose the next action.
                records.append({})
        if rank == 0:
            actions = np.asarray([row["action"] for row in records])
            rewards = np.asarray([row["mean_reward"] for row in records])
            incumbent = select_incumbent(actions, rewards)
            state["incumbents"][method] = {
                "action": incumbent.action.tolist(),
                "development_reward": incumbent.reward,
                "query_index": incumbent.query_index,
            }
            atomic_json(args.output, state)

    if args.certificate_radius == 0.0 and rank == 0:
        state["incumbents"]["coneguard"] = {
            "action": [0.0, 0.0, 0.0, 0.0],
            "development_reward": 0.0,
            "query_index": None,
            "abstained": True,
        }
        atomic_json(args.output, state)

    completed_methods = {row["method"] for row in state["evaluation"]}
    for method in ("bayes", "random", "coneguard"):
        if method in completed_methods:
            continue
        if rank == 0:
            action = state["incumbents"][method]["action"]
            action_tensor = torch.as_tensor(action, dtype=torch.float64, device=device)
        else:
            action_tensor = torch.zeros(4, dtype=torch.float64, device=device)
        dist.broadcast(action_tensor, src=0)
        action = action_tensor.cpu().numpy()
        values = eval_evaluator.evaluate(action, f"selected_{method}", metrics=True)
        if rank == 0:
            for index, source in enumerate(evaluation):
                state["evaluation"].append(
                    {
                        "method": method,
                        "source_id": source["source_id"],
                        "action": action.tolist(),
                        "reward_delta": float(values[index, 0]),
                        "margin_reference_as_a": float(values[index, 1]),
                        "margin_probe_as_a": float(values[index, 2]),
                        "pesq_delta": float(values[index, 3]),
                        "stoi_delta": float(values[index, 4]),
                        "si_sdr_delta": float(values[index, 5]),
                        "probe_si_sdr": float(values[index, 6]),
                    }
                )
            atomic_json(args.output, state)
            print(f"evaluation method={method} action={action.tolist()}", flush=True)
    dist.barrier()
    dist.destroy_process_group()


if __name__ == "__main__":
    main()
