#!/usr/bin/env python3
"""Generate checksum-linked paper numbers, tables, and the main result figure."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--paper", type=Path, required=True)
    return parser.parse_args()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    args = parse_args()
    args.paper.mkdir(parents=True, exist_ok=True)
    analyses = {}
    for corpus in ("librispeech", "voicebank"):
        for model in ("nisqa", "qwen", "phi"):
            path = args.results / f"{corpus}_{model}_analysis.json"
            analyses[(corpus, model)] = load(path)
    optimizer_paths = {
        corpus: args.results / f"{corpus}_qwen_optimizer_analysis.json"
        for corpus in ("librispeech", "voicebank")
    }
    optimizer_run_paths = {
        corpus: args.results / f"{corpus}_qwen_optimizer.json"
        for corpus in ("librispeech", "voicebank")
    }
    optimizers = {corpus: load(path) for corpus, path in optimizer_paths.items()}
    optimizer_runs = {
        corpus: load(path) for corpus, path in optimizer_run_paths.items()
    }
    optimizer = optimizers["voicebank"]
    optimizer_run = optimizer_runs["voicebank"]

    table_lines = [
        "| Corpus | Reward | $\\rho$ | mean $R^2$ | pooled $R^2$ | mean sign err. | raw A/B bias | v2 gate |",
        "|---|---|---:|---:|---:|---:|---:|:---:|",
    ]
    for corpus in ("librispeech", "voicebank"):
        for model in ("nisqa", "qwen", "phi"):
            row = analyses[(corpus, model)]
            table_lines.append(
                f"| {corpus} | {model} | {row['certified_radius']:.2f} | "
                f"{row['heldout']['mean_r2']:.3f} | {row['heldout']['r2']:.3f} | "
                f"{row['heldout']['mean_sign_error']:.3f} | "
                f"{row['order_antisymmetry_median_abs_error']:.3f} | "
                f"{'pass' if row['v2_mean_surface_gate_pass'] else 'fail'} |"
            )
    for corpus in ("librispeech", "voicebank"):
        table_lines.extend(["", f"Optimizer evaluation ({corpus}, Qwen):", ""])
        table_lines.extend(
            [
                "| Method | reward mean [95% CI] | PESQ $\\Delta$ | STOI $\\Delta$ | harmful | verified |",
                "|---|---:|---:|---:|---:|:---:|",
            ]
        )
        for method in ("bayes", "random", "coneguard"):
            row = optimizers[corpus]["methods"][method]
            reward = row["outcomes"]["reward_delta"]
            pesq = row["outcomes"]["pesq_delta"]
            stoi = row["outcomes"]["stoi_delta"]
            table_lines.append(
                f"| {method} | {reward['mean']:+.4f} [{reward['ci_low']:+.4f}, "
                f"{reward['ci_high']:+.4f}] | {pesq['mean']:+.3f} | {stoi['mean']:+.3f} | "
                f"{100*row['harmful_source_fraction']:.1f}% | "
                f"{'yes' if row['verified_exploit'] else 'no'} |"
            )
    (args.paper / "results_snapshot.md").write_text(
        "\n".join(table_lines) + "\n", encoding="utf-8"
    )

    random = optimizer["methods"]["random"]
    bayes = optimizer["methods"]["bayes"]
    matched = analyses[("voicebank", "qwen")]["query_efficiency"]["matched_query_count"]
    macros = {
        "NisqaLibriRadius": f"{analyses[('librispeech', 'nisqa')]['certified_radius']:.2f}",
        "NisqaVoiceRadius": f"{analyses[('voicebank', 'nisqa')]['certified_radius']:.2f}",
        "QwenVoiceRtwo": f"{analyses[('voicebank', 'qwen')]['heldout']['mean_r2']:.3f}",
        "PhiVoiceRtwo": f"{analyses[('voicebank', 'phi')]['heldout']['mean_r2']:.3f}",
        "RandomReward": f"{random['outcomes']['reward_delta']['mean']:.4f}",
        "RandomRewardLow": f"{random['outcomes']['reward_delta']['ci_low']:.4f}",
        "RandomRewardHigh": f"{random['outcomes']['reward_delta']['ci_high']:.4f}",
        "RandomPesq": f"{random['outcomes']['pesq_delta']['mean']:.3f}",
        "RandomStoi": f"{random['outcomes']['stoi_delta']['mean']:.3f}",
        "RandomHarmful": f"{100*random['harmful_source_fraction']:.0f}\\%",
        "BayesReward": f"{bayes['outcomes']['reward_delta']['mean']:.4f}",
        "DoptQueries": str(matched["d_opt_queries"]),
        "RandomQueries": str(matched["random_queries"]),
        "QueryReduction": f"{100*matched['query_reduction']:.0f}\\%",
    }
    macro_text = "\n".join(
        f"\\newcommand{{\\{name}}}{{{value}}}" for name, value in macros.items()
    )
    (args.paper / "generated_numbers.tex").write_text(macro_text + "\n", encoding="utf-8")

    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 8,
            "axes.labelsize": 8,
            "axes.titlesize": 8.5,
            "legend.fontsize": 7,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    figure, axes = plt.subplots(1, 2, figsize=(7.08, 2.25), constrained_layout=True)
    colors = {"nisqa": "#2471A3", "qwen": "#C0392B", "phi": "#7D3C98"}
    labels = {"nisqa": "NISQAv2", "qwen": "Qwen2.5-Omni", "phi": "Phi-4-MM"}
    left = axes[0]
    for model in ("nisqa", "qwen", "phi"):
        row = analyses[("voicebank", model)]
        radii = np.asarray(row["certificate_curve"]["radii"])
        upper = np.asarray(row["certificate_curve"]["simultaneous_upper"])
        selected = radii <= 0.60
        left.plot(radii[selected], upper[selected], lw=1.6, color=colors[model], label=labels[model])
    left.axhline(0.0, color="black", lw=0.8, ls="--")
    left.axvline(0.50, color="#555555", lw=0.7, ls=":")
    left.set(xlim=(0, 0.6), ylim=(-1.0, 1.2), xlabel=r"radius $\rho$", ylabel="95% simultaneous upper bound")
    left.set_title("(a) VoiceBank monotonicity certificate")
    left.legend(frameon=False, loc="lower right")
    left.grid(alpha=0.16, lw=0.5)

    right = axes[1]
    evaluation = optimizer_run["evaluation"]
    methods = ("bayes", "random", "coneguard")
    names = ("BO", "Random", "ConeGuard")
    method_colors = ("#E67E22", "#C0392B", "#2471A3")
    rng = np.random.default_rng(20260824)
    for index, (method, color) in enumerate(zip(methods, method_colors)):
        values = np.asarray(
            [row["reward_delta"] for row in evaluation if row["method"] == method],
            dtype=float,
        )
        jitter = rng.uniform(-0.12, 0.12, size=values.size)
        right.scatter(index + jitter, values, s=11, alpha=0.58, color=color, edgecolors="none")
        summary = optimizer["methods"][method]["outcomes"]["reward_delta"]
        right.errorbar(
            index,
            summary["mean"],
            yerr=[[summary["mean"] - summary["ci_low"]], [summary["ci_high"] - summary["mean"]]],
            fmt="D",
            ms=4,
            capsize=3,
            lw=1.2,
            color="black",
            zorder=5,
        )
    right.axhline(0.0, color="black", lw=0.8, ls="--")
    right.set_xticks(range(3), names)
    right.set_ylabel("held-out reward change")
    right.set_title("(b) Fresh optimizer evaluation (16 sources)")
    right.grid(axis="y", alpha=0.16, lw=0.5)
    right.text(
        1,
        right.get_ylim()[0] + 0.02,
        r"Random: $\Delta$PESQ=-3.44, $\Delta$STOI=-0.137",
        ha="center",
        va="bottom",
        fontsize=6.5,
    )
    figure.savefig(args.paper / "main_results.pdf", bbox_inches="tight")
    figure.savefig(args.paper / "main_results.png", dpi=240, bbox_inches="tight")
    plt.close(figure)

    provenance = {
        "inputs": {
            str(path.relative_to(args.results)): sha256(path)
            for path in sorted(
                [
                    *(args.results / f"{corpus}_{model}_analysis.json" for corpus in ("librispeech", "voicebank") for model in ("nisqa", "qwen", "phi")),
                    *optimizer_paths.values(),
                    *optimizer_run_paths.values(),
                ]
            )
        },
        "outputs": {
            name: sha256(args.paper / name)
            for name in ("results_snapshot.md", "generated_numbers.tex", "main_results.pdf", "main_results.png")
        },
    }
    (args.paper / "asset_provenance.json").write_text(
        json.dumps(provenance, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(provenance, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
