#!/usr/bin/env python3
"""Measure order-balanced Qwen2.5-Omni A/B next-token margins."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import soundfile as sf
import torch
import transformers
from transformers import (
    Qwen2_5OmniConfig,
    Qwen2_5OmniProcessor,
    Qwen2_5OmniThinkerForConditionalGeneration,
)


SYSTEM_PROMPT = (
    "You are an expert listener comparing overall speech quality. Consider noise, "
    "coloration, clipping, and temporal dropouts. Ignore the words, speaker identity, "
    "and presentation order. Follow the requested one-letter response format."
)
USER_QUESTION = (
    "Which audio has better overall listening quality? Output exactly one letter: A or B."
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--num-shards", type=int, default=1)
    parser.add_argument("--max-rows", type=int)
    parser.add_argument("--attention", choices=("sdpa", "flash_attention_2"), default="sdpa")
    return parser.parse_args()


def conversation(audio_a: Path, audio_b: Path) -> list[dict]:
    return [
        {"role": "system", "content": [{"type": "text", "text": SYSTEM_PROMPT}]},
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "Audio A:"},
                {"type": "audio", "audio": str(audio_a.resolve())},
                {"type": "text", "text": "Audio B:"},
                {"type": "audio", "audio": str(audio_b.resolve())},
                {"type": "text", "text": USER_QUESTION},
            ],
        },
    ]


def token_id(processor: Qwen2_5OmniProcessor, label: str) -> int:
    ids = processor.tokenizer.encode(label, add_special_tokens=False)
    if len(ids) != 1:
        raise RuntimeError(f"label {label!r} is not one token: {ids}")
    return int(ids[0])


def move_inputs(inputs: dict, device: torch.device, dtype: torch.dtype) -> dict:
    moved = {}
    for key, value in inputs.items():
        if not isinstance(value, torch.Tensor):
            moved[key] = value
        elif torch.is_floating_point(value):
            moved[key] = value.to(device=device, dtype=dtype)
        else:
            moved[key] = value.to(device=device)
    return moved


def next_token_margin(
    model: Qwen2_5OmniThinkerForConditionalGeneration,
    processor: Qwen2_5OmniProcessor,
    audio_a: Path,
    audio_b: Path,
    a_id: int,
    b_id: int,
) -> float:
    messages = conversation(audio_a, audio_b)
    prompt = processor.apply_chat_template(messages, add_generation_prompt=True, tokenize=False)
    audios = []
    for path in (audio_a, audio_b):
        waveform, sample_rate = sf.read(path, dtype="float32", always_2d=False)
        if waveform.ndim == 2:
            waveform = waveform.mean(axis=1)
        if sample_rate != 16000:
            raise ValueError(f"Qwen input must be 16 kHz, got {sample_rate}: {path}")
        audios.append(waveform)
    batch = processor(
        text=prompt,
        audio=audios,
        return_tensors="pt",
        padding=True,
        use_audio_in_video=False,
    )
    inputs = move_inputs(batch, model.device, model.dtype)
    with torch.inference_mode():
        outputs = model(**inputs, use_cache=False, return_dict=True)
    logits = getattr(outputs, "logits", None)
    if logits is None:
        raise RuntimeError(f"Qwen thinker output has no logits: {type(outputs).__name__}")
    last = logits[0, -1].float()
    margin = last[a_id] - last[b_id]
    if not torch.isfinite(margin):
        raise RuntimeError("non-finite A/B margin")
    return float(margin.cpu())


def main() -> None:
    args = parse_args()
    if args.num_shards < 1 or not 0 <= args.shard_index < args.num_shards:
        raise ValueError("invalid shard configuration")
    with args.manifest.open(newline="", encoding="utf-8") as handle:
        all_rows = list(csv.DictReader(handle))
    rows = [row for index, row in enumerate(all_rows) if index % args.num_shards == args.shard_index]
    if args.max_rows is not None:
        rows = rows[: args.max_rows]
    args.output.parent.mkdir(parents=True, exist_ok=True)

    processor = Qwen2_5OmniProcessor.from_pretrained(args.model, use_fast=False)
    a_id, b_id = token_id(processor, "A"), token_id(processor, "B")
    if a_id == b_id:
        raise RuntimeError("A and B resolve to the same token")
    full_config = Qwen2_5OmniConfig.from_pretrained(args.model)
    model = Qwen2_5OmniThinkerForConditionalGeneration.from_pretrained(
        args.model,
        config=full_config.thinker_config,
        torch_dtype=torch.float16,
        device_map="auto",
        attn_implementation=args.attention,
    )
    model.eval()

    completed: set[tuple[str, str]] = set()
    if args.output.exists():
        for line in args.output.read_text(encoding="utf-8").splitlines():
            record = json.loads(line)
            completed.add((record["source_id"], record["probe_id"]))
    metadata = {
        "model": args.model,
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "dtype": "float16",
        "attention": args.attention,
        "shard_index": args.shard_index,
        "num_shards": args.num_shards,
        "token_ids": {"A": a_id, "B": b_id},
        "system_prompt": SYSTEM_PROMPT,
        "user_question": USER_QUESTION,
        "prompt_sha256": hashlib.sha256(
            (SYSTEM_PROMPT + "\n" + USER_QUESTION).encode()
        ).hexdigest(),
    }
    args.output.with_suffix(args.output.suffix + ".meta.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    written = len(completed)
    with args.output.open("a", encoding="utf-8") as sink:
        for row in rows:
            key = (row["source_id"], row["probe_id"])
            if key in completed:
                continue
            reference = Path(row["reference_audio"])
            probe = Path(row["probe_audio"])
            if not reference.is_file() or not probe.is_file():
                raise FileNotFoundError(reference if not reference.is_file() else probe)
            reference_first = next_token_margin(model, processor, reference, probe, a_id, b_id)
            probe_first = next_token_margin(model, processor, probe, reference, a_id, b_id)
            oriented = 0.5 * (reference_first - probe_first)
            record = {
                **row,
                "margin_reference_as_a": reference_first,
                "margin_probe_as_a": probe_first,
                "reference_preference_margin": oriented,
                "reward_delta_probe_minus_reference": -oriented,
                "model": args.model,
                "dtype": "float16",
            }
            sink.write(json.dumps(record, ensure_ascii=False) + "\n")
            sink.flush()
            written += 1
            print(
                f"[{written}/{len(rows)}] {row['source_id']} {row['probe_id']} delta={-oriented:.4f}",
                flush=True,
            )


if __name__ == "__main__":
    main()
