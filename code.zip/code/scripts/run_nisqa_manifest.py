#!/usr/bin/env python3
"""Run official NISQAv2 MOS on a ConeGuard manifest as positive control."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--nisqa-repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--python", default="python3")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--num-workers", type=int, default=8)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    python_executable = args.python
    expanded_python = Path(args.python).expanduser()
    if expanded_python.exists():
        # Preserve the virtualenv launcher instead of resolving its symlink to
        # the base interpreter, which would silently drop the venv site-packages.
        python_executable = os.path.abspath(expanded_python)
    with args.manifest.open(newline="", encoding="utf-8") as handle:
        manifest = list(csv.DictReader(handle))
    if not manifest:
        raise ValueError("empty manifest")
    work = args.output.parent / f".{args.output.stem}_nisqa"
    work.mkdir(parents=True, exist_ok=True)
    prediction_manifest = work / "manifest.csv"
    audio_rows: dict[str, dict[str, str]] = {}
    for row in manifest:
        reference_key = f"{row['source_id']}::identity"
        probe_key = f"{row['source_id']}::{row['probe_id']}"
        audio_rows[reference_key] = {
            "row_id": reference_key,
            "audio": str(Path(row["reference_audio"]).resolve()),
        }
        audio_rows[probe_key] = {
            "row_id": probe_key,
            "audio": str(Path(row["probe_audio"]).resolve()),
        }
    for row in audio_rows.values():
        if not Path(row["audio"]).is_file():
            raise FileNotFoundError(row["audio"])
    with prediction_manifest.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["row_id", "audio"])
        writer.writeheader()
        writer.writerows(audio_rows.values())

    command = [
        python_executable,
        str((args.nisqa_repo / "run_predict.py").resolve()),
        "--mode",
        "predict_csv",
        "--pretrained_model",
        str((args.nisqa_repo / "weights/nisqa.tar").resolve()),
        "--data_dir",
        "",
        "--csv_file",
        str(prediction_manifest.resolve()),
        "--csv_deg",
        "audio",
        "--num_workers",
        str(args.num_workers),
        "--bs",
        str(args.batch_size),
        "--output_dir",
        str(work.resolve()),
    ]
    subprocess.run(command, cwd=args.nisqa_repo, check=True)
    with (work / "NISQA_results.csv").open(newline="", encoding="utf-8") as handle:
        predictions = list(csv.DictReader(handle))
    scores = {row["row_id"]: float(row["mos_pred"]) for row in predictions}
    if set(scores) != set(audio_rows):
        raise ValueError("NISQA output keys do not match the submitted audio manifest")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as sink:
        for row in manifest:
            reference_score = scores[f"{row['source_id']}::identity"]
            probe_score = scores[f"{row['source_id']}::{row['probe_id']}"]
            margin = reference_score - probe_score
            sink.write(
                json.dumps(
                    {
                        **row,
                        "margin_reference_as_a": margin,
                        "margin_probe_as_a": -margin,
                        "reference_preference_margin": margin,
                        "reward_delta_probe_minus_reference": probe_score - reference_score,
                        "reference_score": reference_score,
                        "probe_score": probe_score,
                        "model": "NISQAv2-official",
                        "interface": "direct scalar MOS difference",
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )
    weights = args.nisqa_repo / "weights/nisqa.tar"
    weight_sha256 = hashlib.sha256(weights.read_bytes()).hexdigest()
    try:
        repo_commit = subprocess.check_output(
            ["git", "-C", str(args.nisqa_repo), "rev-parse", "HEAD"], text=True
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        repo_commit = None
    args.output.with_suffix(args.output.suffix + ".meta.json").write_text(
        json.dumps(
            {
                "model": "NISQAv2-official",
                "weights": str(weights.resolve()),
                "weights_sha256": weight_sha256,
                "repository_commit": repo_commit,
                "interface": "direct scalar MOS difference; no A/B prompt",
                "unique_audio": len(audio_rows),
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"wrote={len(manifest)} unique_audio={len(audio_rows)} output={args.output}")


if __name__ == "__main__":
    main()
