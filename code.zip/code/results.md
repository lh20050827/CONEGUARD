# Frozen-results summary

All values below are generated from `artifacts/results`; failed gates remain
visible. "Radius" is the computed operational radius. Phi--Libri's radius is
withheld as a certificate because its mean-surface fit gate fails.

## Surface audits

| Corpus | Reward | Radius | held-out mean R2 | pooled R2 | mean sign error | format |
|---|---|---:|---:|---:|---:|:---:|
| LibriSpeech | NISQAv2 | 0.50 | 0.827 | 0.452 | 0.000 | pass |
| LibriSpeech | Qwen2.5-Omni | 0.00 | 0.793 | 0.262 | 0.281 | pass |
| LibriSpeech | Phi-4-MM | 0.00 (withheld) | 0.295 | 0.004 | 0.000 | pass |
| VoiceBank | NISQAv2 | 0.49 | 0.735 | 0.456 | 0.000 | pass |
| VoiceBank | Qwen2.5-Omni | 0.00 | 0.781 | 0.414 | 0.125 | pass |
| VoiceBank | Phi-4-MM | 0.00 | 0.631 | 0.027 | 0.219 | pass |

- All 7,168 Audio-LLM source--probe pairs are finite and use single-token A/B
  labels.
- Qwen has positive degradation-reward probe means on 19/56 LibriSpeech and
  6/56 VoiceBank actions; Phi has 54/56 and 26/56 respectively.
- NISQAv2 has 0/56 positive probe means on both corpora.
- VoiceBank NISQAv2 stays at radius 0.49 with 10,000 refits; the simultaneous
  upper bound at radius 0.50 is +0.012537, so the frozen 0.50 gate fails.
- The matched conditional design count is 24 D-optimal versus 40 random probes
  for all six surfaces, a 40% reduction.

## Fresh sequential optimizer evaluations

| Corpus | Method | reward mean [95% CI] | PESQ delta | STOI delta | harmful | verified |
|---|---|---:|---:|---:|---:|:---:|
| LibriSpeech | BO | .233 [.142, .325] | -3.488 | -.204 | 87.5% | yes |
| LibriSpeech | random | .227 [.114, .323] | -3.403 | -.217 | 87.5% | yes |
| LibriSpeech | ConeGuard | .000 [.000, .000] | .000 | .000 | 0% | no exploit |
| VoiceBank | BO | .069 [-.047, .172] | -3.469 | -.194 | 62.5% | no |
| VoiceBank | random | .118 [.050, .185] | -3.437 | -.137 | 75.0% | yes |
| VoiceBank | ConeGuard | .000 [.000, .000] | .000 | .000 | 0% | no exploit |

One optimizer query is one global action averaged over all 16 development
sources. Each selected incumbent is evaluated once on the untouched 16-source
split. The three verified reward intervals remain positive under a post-hoc
four-comparison Bonferroni 98.75% sensitivity analysis; VoiceBank BO remains
negative. ConeGuard's zero-radius identity fallback reduces every observed
harmful-source fraction to zero.

## Analytic-truth implementation validation

This check is post-hoc and is not confirmatory evidence. Across 200 simulated
datasets per case with 32 source clusters and 300 bootstrap refits:

- safe radius-1 quadratic: 200/200 origin passes, median radius 1.00;
- true radius-0.50 boundary: median 0.42, 199/200 estimates no larger than 0.50;
- positive derivative at the origin: 0/200 origin passes, median radius 0.00.

## Test and artifact status

- Unit tests: 23 passed.
- Paper: 4 technical pages plus references-only page 5; all fonts embedded;
  no LaTeX warnings or overfull boxes.
- Main paper asset hashes are in `paper/generated/asset_provenance.json`.
- The deliverable archive contains its own `MANIFEST.sha256`.
