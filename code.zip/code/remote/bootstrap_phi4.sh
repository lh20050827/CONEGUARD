#!/usr/bin/env bash
set -Eeuo pipefail

overlay="${1:-/home/tiger/python_overlays/coneguard_phi4_4482_nodeps_v1}"
mkdir -p "${overlay}"
python3 -m pip install --upgrade --no-deps --target "${overlay}" \
  --index-url https://bytedpypi.byted.org/simple/ \
  'transformers==4.48.2' 'tokenizers==0.21.4' \
  'accelerate==1.3.0' 'peft==0.13.2' \
  'backoff==2.2.1'
PYTHONPATH="${overlay}${PYTHONPATH:+:${PYTHONPATH}}" python3 - <<'PY'
import accelerate
import backoff
import peft
import torch
import transformers

assert torch.__version__.startswith("2.6.0"), torch.__version__
assert torch.cuda.is_available()
assert transformers.__version__ == "4.48.2"
assert peft.__version__ == "0.13.2"
assert accelerate.__version__ == "1.3.0"
assert backoff.__version__ == "2.2.1"
print({
    "torch": torch.__version__,
    "cuda": torch.version.cuda,
    "transformers": transformers.__version__,
    "peft": peft.__version__,
    "accelerate": accelerate.__version__,
    "backoff": backoff.__version__,
})
PY
