#!/usr/bin/env bash
set -Eeuo pipefail

manifest="${1:?usage: launch_phi4_shards.sh MANIFEST OUTPUT_DIR [MODEL] [OVERLAY]}"
output_dir="${2:?usage: launch_phi4_shards.sh MANIFEST OUTPUT_DIR [MODEL] [OVERLAY]}"
model="${3:-/home/tiger/cal_models/Phi-4-multimodal-instruct}"
overlay="${4:-/home/tiger/python_overlays/coneguard_phi4_4482_nodeps_v1}"
num_shards=8

test -f "${manifest}"
test -f "${model}/config.json"
test -f "${overlay}/transformers/__init__.py"
mkdir -p "${output_dir}" "${output_dir}/logs"
if [[ "$(nvidia-smi --query-gpu=name --format=csv,noheader | wc -l)" -ne 8 ]]; then
  echo "expected exactly 8 visible GPUs" >&2
  exit 3
fi

pids=()
for shard in $(seq 0 7); do
  CUDA_VISIBLE_DEVICES="${shard}" \
    PYTHONPATH="${overlay}:tomography/src${PYTHONPATH:+:${PYTHONPATH}}" \
    python3 tomography/scripts/run_phi4_pairwise_margin.py \
      --manifest "${manifest}" \
      --output "${output_dir}/phi4_shard_${shard}.jsonl" \
      --model "${model}" \
      --shard-index "${shard}" \
      --num-shards "${num_shards}" \
      > "${output_dir}/logs/phi4_shard_${shard}.log" 2>&1 &
  pids+=("$!")
done

failed=0
for pid in "${pids[@]}"; do
  if ! wait "${pid}"; then
    failed=1
  fi
done
if [[ "${failed}" -ne 0 ]]; then
  echo "one or more Phi-4 shards failed" >&2
  exit 4
fi
wc -l "${output_dir}"/phi4_shard_*.jsonl
