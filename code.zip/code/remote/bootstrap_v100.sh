#!/usr/bin/env bash
set -Eeuo pipefail

project_root="${1:-/home/tiger/coneguard_project}"
runtime_root="/mnt/hdfs/bmad-checkpoints/black-box-distillation/table_a/3b_p0/runtime_cache/py39_vllm085_torch260_cu124_20260719_v1"
runtime_archive="${runtime_root}/home_tiger_dot_local.tar"
qwen_revision="ae9e1690543ffd5c0221dc27f79834d0294cba00"
qwen_snapshot="/mnt/hdfs/bmad-checkpoints/causal_audio_lattice/hf_home/hub/models--Qwen--Qwen2.5-Omni-7B/snapshots/${qwen_revision}"
qwen_local="/home/tiger/cal_models/Qwen2.5-Omni-7B"

cd "${project_root}"
test -f tomography/protocol.md
test -s "${runtime_archive}"
if ! python3 -c 'import torch, transformers' >/dev/null 2>&1; then
  tar -C /home/tiger -xf "${runtime_archive}"
fi
export PATH="/home/tiger/.local/bin:${PATH}"
python3 -m pip install --user --index-url 'https://bytedpypi.byted.org/simple/' \
  'numpy>=1.24,<2' 'soundfile>=0.12,<1' 'scipy>=1.10,<1.14' \
  'pandas>=2,<3' 'librosa>=0.10,<0.11' 'matplotlib>=3.7,<4' \
  'scikit-learn>=1.3,<1.6' 'tqdm>=4.60,<5' 'PyYAML>=6,<7' 'pytest>=8,<9'

mkdir -p /home/tiger/cal_models
test -f "${qwen_snapshot}/config.json"
if [[ ! -f "${qwen_local}/config.json" ]]; then
  mkdir -p "${qwen_local}"
  cp -LR "${qwen_snapshot}/." "${qwen_local}/"
fi

PYTHONPATH=tomography/src python3 -m pytest -q tomography/tests
PYTHONPATH=tomography/src python3 - <<'PY'
import json
import torch
import transformers

assert torch.cuda.is_available()
assert torch.cuda.device_count() == 8, torch.cuda.device_count()
names = [torch.cuda.get_device_name(index) for index in range(8)]
capabilities = [torch.cuda.get_device_capability(index) for index in range(8)]
assert all("V100" in name for name in names), names
native_bf16 = []
for index in range(8):
    with torch.cuda.device(index):
        native_bf16.append(torch.cuda.is_bf16_supported(including_emulation=False))
assert not any(native_bf16), native_bf16
assert all(capability == (7, 0) for capability in capabilities), capabilities
print(json.dumps({
    "torch": torch.__version__,
    "cuda": torch.version.cuda,
    "transformers": transformers.__version__,
    "gpu_names": names,
    "gpu_capabilities": capabilities,
    "native_bf16": native_bf16,
    "inference_dtype": "float16",
}, sort_keys=True))
PY
echo "runtime_ready model=${qwen_local} revision=${qwen_revision}"
