#!/usr/bin/env bash
set -Eeuo pipefail

project_root="${1:-/home/tiger/coneguard_project}"
data_root="${2:-/home/tiger/coneguard_public_data}"
libri_url="${LIBRI_URL:-https://www.openslr.org/resources/12/test-clean.tar.gz}"
voicebank_url="${VOICEBANK_URL:-https://datashare.ed.ac.uk/bitstreams/dec213d3-bf57-4777-9663-c24bdce92d5e/download}"

cd "${project_root}"
mkdir -p "${data_root}/archives" "${data_root}/extracted" tomography/artifacts/corpora

download_verified() {
  local url="$1"
  local destination="$2"
  local expected_md5="$3"
  if [[ -f "${destination}" ]] && [[ "$(md5sum "${destination}" | awk '{print $1}')" == "${expected_md5}" ]]; then
    return
  fi
  curl -L --fail --retry 8 --retry-delay 5 --continue-at - \
    --output "${destination}" "${url}"
  local actual
  actual="$(md5sum "${destination}" | awk '{print $1}')"
  if [[ "${actual}" != "${expected_md5}" ]]; then
    echo "MD5 mismatch for ${destination}: expected=${expected_md5} actual=${actual}" >&2
    exit 4
  fi
}

libri_archive="${data_root}/archives/test-clean.tar.gz"
voicebank_archive="${data_root}/archives/clean_testset_wav.zip"
download_verified "${libri_url}" "${libri_archive}" "32fa31d27d2e1cad72775fee3f4849a9"
download_verified "${voicebank_url}" "${voicebank_archive}" "34eb1c0ba7ef667e9b966866c542fc16"

if [[ ! -d "${data_root}/extracted/LibriSpeech/test-clean" ]]; then
  tar -C "${data_root}/extracted" -xzf "${libri_archive}"
fi
if [[ ! -d "${data_root}/extracted/clean_testset_wav" ]]; then
  python3 -m zipfile -e "${voicebank_archive}" "${data_root}/extracted"
fi

PYTHONPATH=tomography/src python3 tomography/scripts/select_public_sources.py \
  --corpus librispeech \
  --root "${data_root}/extracted/LibriSpeech/test-clean" \
  --count 64 \
  --output tomography/artifacts/corpora/librispeech_sources_all64.csv
PYTHONPATH=tomography/src python3 tomography/scripts/select_public_sources.py \
  --corpus voicebank \
  --root "${data_root}/extracted/clean_testset_wav" \
  --count 64 \
  --output tomography/artifacts/corpora/voicebank_sources_all64.csv

for corpus in librispeech voicebank; do
  PYTHONPATH=tomography/src python3 tomography/scripts/partition_source_roles.py \
    --sources "tomography/artifacts/corpora/${corpus}_sources_all64.csv" \
    --surface-output "tomography/artifacts/corpora/${corpus}_sources.csv" \
    --optimizer-dev-output "tomography/artifacts/corpora/${corpus}_optimizer_dev.csv" \
    --optimizer-eval-output "tomography/artifacts/corpora/${corpus}_optimizer_eval.csv"
  PYTHONPATH=tomography/src python3 tomography/scripts/validate_degradation_axes.py \
    --sources "tomography/artifacts/corpora/${corpus}_sources_all64.csv" \
    --output "tomography/artifacts/corpora/${corpus}_axis_validation.json"
  PYTHONPATH=tomography/src python3 tomography/scripts/build_probe_corpus.py \
    --sources "tomography/artifacts/corpora/${corpus}_sources.csv" \
    --output-root "tomography/artifacts/corpora/${corpus}_probe24" \
    --n-select 24 \
    --heldout 32
done

md5sum "${libri_archive}" "${voicebank_archive}" > tomography/artifacts/corpora/ARCHIVE_MD5SUMS
echo "public_corpora_ready root=${data_root}"
