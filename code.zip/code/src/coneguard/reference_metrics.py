"""Dependency-light reference metrics used for probe validity gates."""

from __future__ import annotations

import numpy as np


def si_sdr(reference: np.ndarray, estimate: np.ndarray, eps: float = 1e-12) -> float:
    """Scale-invariant signal-to-distortion ratio in dB."""

    ref = np.asarray(reference, dtype=float).reshape(-1)
    est = np.asarray(estimate, dtype=float).reshape(-1)
    if ref.shape != est.shape or ref.size == 0:
        raise ValueError("reference and estimate must be equal non-empty vectors")
    ref = ref - ref.mean()
    est = est - est.mean()
    target = np.dot(est, ref) * ref / (np.dot(ref, ref) + eps)
    residual = est - target
    ratio = (np.dot(target, target) + eps) / (np.dot(residual, residual) + eps)
    return float(10.0 * np.log10(ratio))
