"""Deterministic black-box optimizers for the preregistered stress test."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import linalg
from scipy.stats import norm, qmc


DIMENSION = 4
BO_SEED = 20260824
RANDOM_SEED = 20260825
POOL_SIZE = 4096
INITIAL_POINTS = 8
QUERY_BUDGET = 40
LENGTH_SCALE = 0.25
GP_NOISE = 1e-4
EI_XI = 0.01


def sobol_candidate_pool(
    *, seed: int = BO_SEED, size: int = POOL_SIZE, radius: float = 1.0
) -> np.ndarray:
    """Return the sealed scrambled-Sobol action pool in deterministic order."""

    if size < 1 or size & (size - 1):
        raise ValueError("Sobol pool size must be a positive power of two")
    if not 0.0 < radius <= 1.0:
        raise ValueError("radius must lie in (0,1]")
    exponent = int(np.log2(size))
    pool = qmc.Sobol(d=DIMENSION, scramble=True, seed=seed).random_base2(exponent)
    return np.asarray(pool * radius, dtype=np.float64)


def random_actions(
    *, seed: int = RANDOM_SEED, budget: int = QUERY_BUDGET
) -> np.ndarray:
    """Return the frozen PCG64 uniform-random search actions."""

    if budget < 1:
        raise ValueError("budget must be positive")
    return np.random.default_rng(seed).uniform(0.0, 1.0, size=(budget, DIMENSION))


def matern52_kernel(
    left: np.ndarray, right: np.ndarray, *, length_scale: float = LENGTH_SCALE
) -> np.ndarray:
    """Unit-amplitude isotropic Matérn-5/2 covariance."""

    x = np.atleast_2d(np.asarray(left, dtype=np.float64))
    z = np.atleast_2d(np.asarray(right, dtype=np.float64))
    if x.shape[1] != DIMENSION or z.shape[1] != DIMENSION:
        raise ValueError("actions must have four coordinates")
    if length_scale <= 0:
        raise ValueError("length_scale must be positive")
    distance = np.sqrt(
        np.maximum(
            np.sum(((x[:, None, :] - z[None, :, :]) / length_scale) ** 2, axis=2),
            0.0,
        )
    )
    scaled = np.sqrt(5.0) * distance
    return (1.0 + scaled + scaled**2 / 3.0) * np.exp(-scaled)


def expected_improvement(
    observed_actions: np.ndarray,
    observed_rewards: np.ndarray,
    candidates: np.ndarray,
    *,
    xi: float = EI_XI,
    noise: float = GP_NOISE,
) -> np.ndarray:
    """Expected improvement in standardized-reward units."""

    x = np.asarray(observed_actions, dtype=np.float64)
    y = np.asarray(observed_rewards, dtype=np.float64)
    candidates = np.asarray(candidates, dtype=np.float64)
    if x.ndim != 2 or x.shape[1] != DIMENSION or y.shape != (x.shape[0],):
        raise ValueError("observations must be n-by-4 actions and n rewards")
    if x.shape[0] < 1 or not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
        raise ValueError("observations must be non-empty and finite")
    if candidates.ndim != 2 or candidates.shape[1] != DIMENSION:
        raise ValueError("candidates must be n-by-4")
    if noise <= 0 or xi < 0:
        raise ValueError("noise must be positive and xi non-negative")

    scale = float(y.std())
    standardized = (y - y.mean()) / (scale if scale > 1e-12 else 1.0)
    covariance = matern52_kernel(x, x) + noise * np.eye(x.shape[0])
    try:
        factor = linalg.cholesky(covariance, lower=True, check_finite=False)
    except linalg.LinAlgError:
        factor = linalg.cholesky(
            covariance + 1e-8 * np.eye(x.shape[0]), lower=True, check_finite=False
        )
    alpha = linalg.cho_solve((factor, True), standardized, check_finite=False)
    cross = matern52_kernel(x, candidates)
    mean = cross.T @ alpha
    projected = linalg.solve_triangular(factor, cross, lower=True, check_finite=False)
    variance = np.maximum(1.0 - np.sum(projected**2, axis=0), 0.0)
    sigma = np.sqrt(variance)
    improvement = mean - float(standardized.max()) - xi
    result = np.zeros(candidates.shape[0], dtype=np.float64)
    nonzero = sigma > 1e-12
    z_score = improvement[nonzero] / sigma[nonzero]
    result[nonzero] = (
        improvement[nonzero] * norm.cdf(z_score) + sigma[nonzero] * norm.pdf(z_score)
    )
    return result


def next_bayes_action(
    observed_actions: np.ndarray,
    observed_rewards: np.ndarray,
    *,
    radius: float = 1.0,
    pool: np.ndarray | None = None,
) -> tuple[int, np.ndarray]:
    """Return `(sealed_pool_index, action)` for the next BO query."""

    candidates = sobol_candidate_pool(radius=radius) if pool is None else np.asarray(pool)
    x = np.asarray(observed_actions, dtype=np.float64)
    y = np.asarray(observed_rewards, dtype=np.float64)
    if x.size == 0:
        x = np.empty((0, DIMENSION), dtype=np.float64)
    if x.ndim != 2 or x.shape[1] != DIMENSION or y.shape != (x.shape[0],):
        raise ValueError("observed actions/rewards have incompatible shapes")
    if x.shape[0] >= QUERY_BUDGET:
        raise ValueError("query budget is exhausted")

    used = np.zeros(candidates.shape[0], dtype=bool)
    for action in x:
        matches = np.flatnonzero(np.all(candidates == action, axis=1))
        if matches.size:
            used[matches[0]] = True
    if x.shape[0] < INITIAL_POINTS:
        available_initial = np.flatnonzero(~used)[: INITIAL_POINTS - x.shape[0]]
        if not available_initial.size:
            raise RuntimeError("sealed initial design is exhausted")
        index = int(available_initial[0])
    else:
        available = np.flatnonzero(~used)
        if not available.size:
            raise RuntimeError("candidate pool is exhausted")
        utility = expected_improvement(x, y, candidates[available])
        index = int(available[int(np.argmax(utility))])
    return index, np.asarray(candidates[index], dtype=np.float64)


@dataclass(frozen=True)
class Incumbent:
    action: np.ndarray
    reward: float
    query_index: int | None


def select_incumbent(actions: np.ndarray, rewards: np.ndarray) -> Incumbent:
    """Select the best queried action, retaining identity unless gain is positive."""

    x = np.asarray(actions, dtype=np.float64)
    y = np.asarray(rewards, dtype=np.float64)
    if x.ndim != 2 or x.shape[1] != DIMENSION or y.shape != (x.shape[0],):
        raise ValueError("actions/rewards have incompatible shapes")
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
        raise ValueError("actions/rewards must be finite")
    if y.size == 0 or float(y.max()) <= 0.0:
        return Incumbent(np.zeros(DIMENSION, dtype=np.float64), 0.0, None)
    index = int(np.argmax(y))
    return Incumbent(np.asarray(x[index], dtype=np.float64), float(y[index]), index)
