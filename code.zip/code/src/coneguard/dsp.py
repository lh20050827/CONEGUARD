"""Deterministic continuous audio degradations used by the declared cone."""

from __future__ import annotations

import hashlib

import numpy as np
from scipy import signal


def _seed(source_id: str, axis: str) -> int:
    digest = hashlib.sha256(f"{source_id}:{axis}".encode()).digest()
    return int.from_bytes(digest[:8], "little")


def normalize_rms(audio: np.ndarray, target_dbfs: float = -26.0) -> np.ndarray:
    x = np.asarray(audio, dtype=np.float64)
    if x.ndim != 1 or x.size == 0:
        raise ValueError("audio must be a non-empty mono vector")
    rms = np.sqrt(np.mean(x**2))
    if rms < 1e-10:
        raise ValueError("audio is silent")
    target = 10.0 ** (target_dbfs / 20.0)
    y = x * (target / rms)
    peak = np.max(np.abs(y))
    return y * (0.90 / peak) if peak > 0.90 else y


def _colored_noise(length: int, rng: np.random.Generator) -> np.ndarray:
    white = rng.standard_normal(length)
    sos = signal.butter(2, [150, 7000], btype="bandpass", fs=16000, output="sos")
    noise = signal.sosfilt(sos, white)
    return noise / (np.sqrt(np.mean(noise**2)) + 1e-12)


def _drop_mask(length: int, source_id: str, sample_rate: int) -> np.ndarray:
    rng = np.random.default_rng(_seed(source_id, "dropout"))
    mask = np.ones(length, dtype=np.float64)
    frame = max(1, int(0.020 * sample_rate))
    ramp = max(1, int(0.003 * sample_rate))
    count = max(1, int(np.ceil(length / sample_rate * 5)))
    starts = rng.integers(0, max(1, length - frame), size=count)
    for start in starts:
        stop = min(length, start + frame)
        mask[start:stop] = 0.0
        left = min(ramp, start)
        if left:
            mask[start - left : start] *= np.linspace(1.0, 0.0, left, endpoint=False)
        right = min(ramp, length - stop)
        if right:
            mask[stop : stop + right] *= np.linspace(0.0, 1.0, right, endpoint=False)
    return mask


def apply_degradation_cone(
    audio: np.ndarray,
    severities: np.ndarray,
    *,
    source_id: str,
    sample_rate: int = 16000,
) -> np.ndarray:
    """Apply noise, band limitation, dropout, and clipping in fixed order."""

    if sample_rate != 16000:
        raise ValueError("the frozen cone requires 16 kHz audio")
    u = np.asarray(severities, dtype=float)
    if u.shape != (4,) or np.any((u < 0) | (u > 1)):
        raise ValueError("severities must be four values in [0,1]")
    y = normalize_rms(audio)

    rng = np.random.default_rng(_seed(source_id, "noise"))
    noise = _colored_noise(len(y), rng)
    max_noise_rms = np.sqrt(np.mean(y**2)) * 10.0 ** (-5.0 / 20.0)
    y = y + u[0] * max_noise_rms * noise

    sos = signal.butter(6, 3400, btype="lowpass", fs=sample_rate, output="sos")
    lowpassed = signal.sosfiltfilt(sos, y)
    y = (1.0 - u[1]) * y + u[1] * lowpassed

    mask = _drop_mask(len(y), source_id, sample_rate)
    y = y * (1.0 - u[2] * (1.0 - mask))

    threshold = max(1e-6, 0.20 * np.max(np.abs(y)))
    clipped = np.clip(y, -threshold, threshold)
    y = (1.0 - u[3]) * y + u[3] * clipped
    return np.asarray(y, dtype=np.float32)

