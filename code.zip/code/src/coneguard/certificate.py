"""Quadratic response fitting and monotonicity-radius certificates."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .design import quadratic_features


def unpack_coefficients(coefficients: np.ndarray, dimension: int) -> tuple[np.ndarray, np.ndarray]:
    coefficients = np.asarray(coefficients, dtype=float)
    expected = dimension * (dimension + 3) // 2
    if coefficients.shape != (expected,):
        raise ValueError(f"expected {expected} coefficients, got {coefficients.shape}")
    beta = coefficients[:dimension]
    hessian = np.zeros((dimension, dimension), dtype=float)
    hessian[np.diag_indices(dimension)] = coefficients[dimension : 2 * dimension]
    offset = 2 * dimension
    for i in range(dimension):
        for j in range(i + 1, dimension):
            hessian[i, j] = hessian[j, i] = coefficients[offset]
            offset += 1
    return beta, hessian


def fit_surface(severities: np.ndarray, responses: np.ndarray, ridge: float = 1e-6) -> np.ndarray:
    """Fit a pooled no-intercept quadratic to clustered responses.

    `responses` may be one vector or a `(sources, probes)` matrix. In the
    latter case each source observes the same probe design.
    """

    u = np.asarray(severities, dtype=float)
    y = np.asarray(responses, dtype=float)
    x = quadratic_features(u)
    if y.ndim == 1:
        if y.shape[0] != x.shape[0]:
            raise ValueError("response length does not match probes")
        pooled_x, pooled_y = x, y
    elif y.ndim == 2:
        if y.shape[1] != x.shape[0]:
            raise ValueError("response probe dimension does not match design")
        pooled_x = np.tile(x, (y.shape[0], 1))
        pooled_y = y.reshape(-1)
    else:
        raise ValueError("responses must be a vector or source-by-probe matrix")
    if not np.all(np.isfinite(pooled_y)):
        raise ValueError("responses must be finite")
    scale = pooled_x.std(axis=0)
    scale[scale < 1e-12] = 1.0
    xs = pooled_x / scale
    gram = xs.T @ xs + ridge * np.eye(xs.shape[1])
    scaled_coefficients = np.linalg.solve(gram, xs.T @ pooled_y)
    return scaled_coefficients / scale


def predict_surface(severities: np.ndarray, coefficients: np.ndarray) -> np.ndarray:
    """Evaluate the no-intercept quadratic surface at one or more points."""

    x = quadratic_features(severities)
    coefficients = np.asarray(coefficients, dtype=float)
    if coefficients.shape != (x.shape[1],):
        raise ValueError(
            f"expected {x.shape[1]} coefficients, got {coefficients.shape}"
        )
    return x @ coefficients


def worst_coordinate_derivatives(coefficients: np.ndarray, dimension: int, radius: float) -> np.ndarray:
    if radius < 0:
        raise ValueError("radius must be non-negative")
    beta, hessian = unpack_coefficients(coefficients, dimension)
    return beta + radius * np.maximum(hessian, 0.0).sum(axis=1)


@dataclass(frozen=True)
class CertificateResult:
    radius: float
    radii: np.ndarray
    simultaneous_upper: np.ndarray
    bootstrap_coefficients: np.ndarray
    point_coefficients: np.ndarray


def certify_radius(
    severities: np.ndarray,
    responses: np.ndarray,
    *,
    alpha: float = 0.05,
    bootstrap_draws: int = 2000,
    radius_step: float = 0.01,
    seed: int = 20260824,
    ridge: float = 1e-6,
) -> CertificateResult:
    """Return the largest box radius with a negative simultaneous upper bound."""

    y = np.asarray(responses, dtype=float)
    if y.ndim != 2 or y.shape[0] < 2:
        raise ValueError("cluster bootstrap requires at least two source rows")
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie in (0,1)")
    if bootstrap_draws < 100:
        raise ValueError("bootstrap_draws must be at least 100")
    if not 0 < radius_step <= 1:
        raise ValueError("radius_step must lie in (0,1]")
    dimension = np.asarray(severities).shape[1]
    rng = np.random.default_rng(seed)
    point = fit_surface(severities, y, ridge=ridge)
    draws = np.empty((bootstrap_draws, point.size), dtype=float)
    for draw in range(bootstrap_draws):
        indices = rng.integers(0, y.shape[0], size=y.shape[0])
        draws[draw] = fit_surface(severities, y[indices], ridge=ridge)
    radii = np.round(np.arange(0.0, 1.0 + radius_step / 2, radius_step), 10)
    upper = np.empty_like(radii)
    for index, radius in enumerate(radii):
        worst = np.stack(
            [worst_coordinate_derivatives(row, dimension, float(radius)) for row in draws]
        )
        upper[index] = np.quantile(worst.max(axis=1), 1.0 - alpha)
    passing = radii[upper < 0.0]
    radius = float(passing.max()) if passing.size else 0.0
    return CertificateResult(
        radius=radius,
        radii=radii,
        simultaneous_upper=upper,
        bootstrap_coefficients=draws,
        point_coefficients=point,
    )
