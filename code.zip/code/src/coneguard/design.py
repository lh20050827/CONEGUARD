"""D-optimal designs for a no-intercept local quadratic surface."""

from __future__ import annotations

import itertools
from dataclasses import dataclass

import numpy as np


# These indices were sealed with the pre-confirmatory P501 design artifact.
# Persisting them prevents rank-deficient ridge comparisons in the greedy
# warm-start from choosing different symmetry-equivalent paths across BLAS
# implementations. Candidate ordering is itertools.product order.
FROZEN_4D_GRID_INDICES: dict[int, tuple[int, ...]] = {
    14: (13, 123, 603, 619, 523, 224, 549, 389, 94, 21, 586, 78, 377, 323),
    18: (611, 123, 603, 619, 523, 99, 524, 519, 119, 21, 309, 52, 251, 323, 13, 599, 228, 503),
    24: (549, 123, 603, 619, 523, 99, 509, 519, 119, 21, 269, 51, 251, 323, 18, 599, 103, 503, 111, 69, 359, 563, 3, 621),
    # Extended A5 matched-count designs were sealed from the original Linux
    # worker after the final archive audit exposed symmetry-tie BLAS drift.
    28: (621, 123, 603, 523, 619, 499, 3, 519, 23, 71, 311, 613, 269, 373, 109, 503, 599, 103, 559, 261, 19, 349, 13, 101, 573, 119, 303, 501),
    32: (621, 123, 603, 523, 619, 499, 3, 519, 23, 69, 311, 21, 51, 373, 109, 503, 549, 103, 559, 261, 253, 349, 113, 101, 573, 119, 303, 501, 613, 269, 13, 599),
    36: (99, 123, 603, 523, 619, 499, 3, 519, 23, 69, 311, 373, 53, 513, 109, 503, 601, 369, 559, 261, 19, 349, 113, 101, 573, 119, 303, 501, 613, 269, 13, 599, 549, 71, 621, 103),
    40: (563, 123, 603, 523, 619, 499, 3, 519, 23, 69, 311, 549, 51, 369, 109, 503, 601, 99, 569, 261, 19, 349, 113, 101, 573, 119, 303, 501, 613, 269, 13, 599, 73, 21, 621, 103, 253, 373, 398, 509),
    44: (569, 123, 603, 523, 619, 499, 3, 519, 23, 69, 311, 273, 53, 121, 109, 503, 601, 353, 609, 261, 19, 349, 113, 101, 573, 119, 301, 501, 613, 269, 13, 599, 73, 21, 621, 103, 253, 373, 549, 509, 99, 563, 369, 521),
    48: (623, 123, 603, 523, 619, 499, 3, 519, 23, 69, 311, 549, 53, 369, 109, 503, 601, 353, 309, 261, 19, 349, 113, 101, 573, 119, 609, 501, 613, 269, 13, 599, 73, 21, 621, 103, 253, 373, 513, 509, 99, 553, 569, 521, 61, 273, 121, 301),
    64: (623, 123, 603, 523, 619, 499, 3, 519, 23, 69, 311, 224, 102, 301, 109, 503, 574, 353, 309, 261, 19, 349, 113, 101, 573, 119, 378, 501, 613, 269, 13, 599, 73, 21, 620, 103, 253, 373, 513, 509, 99, 553, 569, 521, 61, 273, 114, 608, 549, 121, 53, 609, 369, 502, 621, 394, 8, 248, 548, 601, 78, 504, 22, 44),
}


def _frozen_canonical_indices(candidates: np.ndarray, n_select: int) -> np.ndarray | None:
    indices = FROZEN_4D_GRID_INDICES.get(n_select)
    if indices is None or candidates.shape != (624, 4):
        return None
    levels = (0.0, 0.25, 0.5, 0.75, 1.0)
    canonical = np.asarray(list(itertools.product(levels, repeat=4)), dtype=float)[1:]
    if not np.array_equal(candidates, canonical):
        return None
    return np.asarray(indices, dtype=int)


def quadratic_features(severities: np.ndarray) -> np.ndarray:
    """Return features for beta'u + .5*u'Hu, without an intercept.

    Columns are linear terms, half-squares, then lexicographic interactions.
    With this convention the fitted square and interaction coefficients map
    directly to the diagonal and upper triangle of the symmetric Hessian.
    """

    u = np.asarray(severities, dtype=float)
    if u.ndim == 1:
        u = u[None, :]
    if u.ndim != 2:
        raise ValueError("severities must be a vector or matrix")
    if not np.all(np.isfinite(u)):
        raise ValueError("severities must be finite")
    linear = u
    squares = 0.5 * u**2
    interactions = [u[:, i] * u[:, j] for i in range(u.shape[1]) for j in range(i + 1, u.shape[1])]
    if interactions:
        return np.column_stack([linear, squares, *interactions])
    return np.column_stack([linear, squares])


@dataclass(frozen=True)
class DesignResult:
    indices: np.ndarray
    logdet: float
    rank: int
    condition_number: float
    raw_condition_number: float
    feature_scale: np.ndarray


def _criterion(x: np.ndarray, ridge: float) -> float:
    gram = x.T @ x + ridge * np.eye(x.shape[1])
    sign, value = np.linalg.slogdet(gram)
    return float(value) if sign > 0 else -np.inf


def d_optimal_design(
    candidates: np.ndarray,
    n_select: int,
    *,
    ridge: float = 1e-9,
    max_exchange_passes: int = 20,
) -> DesignResult:
    """Select a deterministic greedy D-optimal subset with exchanges."""

    candidates = np.asarray(candidates, dtype=float)
    if candidates.ndim != 2:
        raise ValueError("candidates must be a matrix")
    features = quadratic_features(candidates)
    if n_select < features.shape[1]:
        raise ValueError("n_select must be at least the quadratic feature dimension")
    if n_select > len(candidates):
        raise ValueError("n_select exceeds candidate count")
    scale = features.std(axis=0)
    scale[scale < 1e-12] = 1.0
    x = features / scale

    frozen = _frozen_canonical_indices(candidates, n_select)
    if frozen is not None:
        raw = features[frozen]
        return DesignResult(
            indices=frozen,
            logdet=_criterion(x[frozen], ridge),
            rank=int(np.linalg.matrix_rank(raw)),
            condition_number=float(np.linalg.cond(raw / scale)),
            raw_condition_number=float(np.linalg.cond(raw)),
            feature_scale=scale,
        )

    selected: list[int] = []
    remaining = set(range(len(candidates)))
    for _ in range(n_select):
        best = max(
            remaining,
            key=lambda idx: (_criterion(x[selected + [idx]], ridge), -idx),
        )
        selected.append(best)
        remaining.remove(best)

    current = _criterion(x[selected], ridge)
    for _ in range(max_exchange_passes):
        best_gain = 0.0
        best_swap: tuple[int, int] | None = None
        for position, old_idx in enumerate(selected):
            for new_idx in sorted(remaining):
                proposal = selected.copy()
                proposal[position] = new_idx
                value = _criterion(x[proposal], ridge)
                gain = value - current
                if gain > best_gain + 1e-12:
                    best_gain = gain
                    best_swap = (position, new_idx)
        if best_swap is None:
            break
        position, new_idx = best_swap
        old_idx = selected[position]
        selected[position] = new_idx
        remaining.remove(new_idx)
        remaining.add(old_idx)
        current += best_gain

    selected_array = np.asarray(selected, dtype=int)
    raw = features[selected_array]
    return DesignResult(
        indices=selected_array,
        logdet=current,
        rank=int(np.linalg.matrix_rank(raw)),
        condition_number=float(np.linalg.cond(raw / scale)),
        raw_condition_number=float(np.linalg.cond(raw)),
        feature_scale=scale,
    )
