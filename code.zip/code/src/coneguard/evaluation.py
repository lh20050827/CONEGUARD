"""Pre-registered diagnostics for fitted ConeGuard response surfaces."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .certificate import fit_surface, predict_surface


@dataclass(frozen=True)
class SurfaceMetrics:
    # Pooled individual-observation diagnostics retained from protocol v1.
    r2: float
    sign_error: float
    rmse: float
    # Population-mean surface diagnostics aligned with the certificate estimand.
    mean_r2: float
    mean_sign_error: float
    mean_rmse: float
    between_source_rmse: float
    n_observations: int


def heldout_surface_metrics(
    design_severities: np.ndarray,
    design_responses: np.ndarray,
    heldout_severities: np.ndarray,
    heldout_responses: np.ndarray,
    *,
    ridge: float = 1e-6,
) -> SurfaceMetrics:
    """Fit on design probes and score the pooled held-out observations.

    Each source shares the same surface prediction. This deliberately tests the
    pooled model used by the certificate instead of fitting source-specific
    parameters to the held-out set.
    """

    design_y = np.asarray(design_responses, dtype=float)
    heldout_y = np.asarray(heldout_responses, dtype=float)
    if design_y.ndim != 2 or heldout_y.ndim != 2:
        raise ValueError("responses must be source-by-probe matrices")
    if design_y.shape[0] != heldout_y.shape[0]:
        raise ValueError("design and held-out source counts differ")
    if heldout_y.shape[1] != np.asarray(heldout_severities).shape[0]:
        raise ValueError("held-out response probe dimension does not match")
    if not np.all(np.isfinite(design_y)) or not np.all(np.isfinite(heldout_y)):
        raise ValueError("responses must be finite")

    coefficients = fit_surface(design_severities, design_y, ridge=ridge)
    predicted_per_probe = predict_surface(heldout_severities, coefficients)
    predicted = np.tile(predicted_per_probe, heldout_y.shape[0])
    observed = heldout_y.reshape(-1)
    residual = observed - predicted
    denominator = np.sum((observed - observed.mean()) ** 2)
    r2 = float(1.0 - np.sum(residual**2) / denominator) if denominator > 0 else float("nan")
    sign_error = float(np.mean(np.signbit(predicted) != np.signbit(observed)))
    observed_mean = heldout_y.mean(axis=0)
    mean_residual = observed_mean - predicted_per_probe
    mean_denominator = np.sum((observed_mean - observed_mean.mean()) ** 2)
    mean_r2 = (
        float(1.0 - np.sum(mean_residual**2) / mean_denominator)
        if mean_denominator > 0
        else float("nan")
    )
    return SurfaceMetrics(
        r2=r2,
        sign_error=sign_error,
        rmse=float(np.sqrt(np.mean(residual**2))),
        mean_r2=mean_r2,
        mean_sign_error=float(
            np.mean(np.signbit(predicted_per_probe) != np.signbit(observed_mean))
        ),
        mean_rmse=float(np.sqrt(np.mean(mean_residual**2))),
        between_source_rmse=float(
            np.sqrt(np.mean((heldout_y - observed_mean[None, :]) ** 2))
        ),
        n_observations=int(observed.size),
    )


def order_antisymmetry_error(reference_as_a: np.ndarray, probe_as_a: np.ndarray) -> np.ndarray:
    """Absolute deviation from the required A/B margin antisymmetry."""

    forward = np.asarray(reference_as_a, dtype=float)
    reverse = np.asarray(probe_as_a, dtype=float)
    if forward.shape != reverse.shape:
        raise ValueError("forward and reverse margins must have the same shape")
    return np.abs(forward + reverse)
