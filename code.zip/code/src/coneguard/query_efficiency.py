"""Monte Carlo query-efficiency comparison for frozen response designs."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .certificate import fit_surface, predict_surface
from .design import d_optimal_design, quadratic_features


@dataclass(frozen=True)
class EfficiencyAtSize:
    n_queries: int
    d_opt_median_error: float
    random_median_error: float
    d_opt_q90_error: float
    random_q90_error: float
    probability_d_opt_better: float


@dataclass(frozen=True)
class MatchedQueryCount:
    reference_queries: int
    tolerance: float
    error_threshold: float
    d_opt_queries: int | None
    random_queries: int | None
    d_opt_right_censored: bool
    random_right_censored: bool
    query_reduction: float | None


def standardized_coefficient_error(
    estimated: np.ndarray, truth: np.ndarray, feature_scale: np.ndarray
) -> float:
    """Relative coefficient error after putting feature columns on one scale."""

    estimated = np.asarray(estimated, dtype=float)
    truth = np.asarray(truth, dtype=float)
    scale = np.asarray(feature_scale, dtype=float)
    if estimated.shape != truth.shape or truth.shape != scale.shape:
        raise ValueError("coefficient and feature-scale shapes differ")
    denominator = np.linalg.norm(truth * scale)
    if denominator <= 0:
        raise ValueError("truth has zero standardized norm")
    return float(np.linalg.norm((estimated - truth) * scale) / denominator)


def simulate_query_efficiency(
    candidates: np.ndarray,
    truth: np.ndarray,
    *,
    noise_scale: float,
    design_sizes: tuple[int, ...] = (14, 18, 24),
    n_sources: int = 32,
    repetitions: int = 1000,
    seed: int = 20260824,
    ridge: float = 1e-6,
) -> list[EfficiencyAtSize]:
    """Compare D-optimal and random subsets under a fitted noise scale.

    One source-by-candidate noise table is shared by all methods within a
    repetition. Random subsets remain independently sampled at each size. The
    simulation never uses judge outputs to choose a probe.
    """

    candidates = np.asarray(candidates, dtype=float)
    truth = np.asarray(truth, dtype=float)
    if candidates.ndim != 2:
        raise ValueError("candidates must be a matrix")
    features = quadratic_features(candidates)
    if truth.shape != (features.shape[1],):
        raise ValueError("truth dimension does not match candidates")
    if noise_scale < 0 or n_sources < 2 or repetitions < 1:
        raise ValueError("invalid simulation settings")
    sizes = tuple(sorted(set(int(size) for size in design_sizes)))
    if not sizes or sizes[0] < features.shape[1] or sizes[-1] > len(candidates):
        raise ValueError("invalid design sizes")

    scale = features.std(axis=0)
    scale[scale < 1e-12] = 1.0
    true_response = predict_surface(candidates, truth)
    d_opt_indices = {
        size: d_optimal_design(candidates, size).indices for size in sizes
    }
    d_errors = {size: np.empty(repetitions, dtype=float) for size in sizes}
    r_errors = {size: np.empty(repetitions, dtype=float) for size in sizes}
    rng = np.random.default_rng(seed)
    for repetition in range(repetitions):
        noise = rng.normal(0.0, noise_scale, size=(n_sources, len(candidates)))
        responses = true_response[None, :] + noise
        for size in sizes:
            d_indices = d_opt_indices[size]
            r_indices = rng.choice(len(candidates), size=size, replace=False)
            d_fit = fit_surface(candidates[d_indices], responses[:, d_indices], ridge=ridge)
            r_fit = fit_surface(candidates[r_indices], responses[:, r_indices], ridge=ridge)
            d_errors[size][repetition] = standardized_coefficient_error(d_fit, truth, scale)
            r_errors[size][repetition] = standardized_coefficient_error(r_fit, truth, scale)

    return [
        EfficiencyAtSize(
            n_queries=size,
            d_opt_median_error=float(np.median(d_errors[size])),
            random_median_error=float(np.median(r_errors[size])),
            d_opt_q90_error=float(np.quantile(d_errors[size], 0.9)),
            random_q90_error=float(np.quantile(r_errors[size], 0.9)),
            probability_d_opt_better=float(np.mean(d_errors[size] < r_errors[size])),
        )
        for size in sizes
    ]


def matched_query_count(
    rows: list[EfficiencyAtSize],
    *,
    reference_queries: int = 24,
    tolerance: float = 0.10,
) -> MatchedQueryCount:
    """Find queries needed to come within tolerance of D-opt at the reference size."""

    if not rows or tolerance < 0:
        raise ValueError("rows must be non-empty and tolerance non-negative")
    ordered = sorted(rows, key=lambda row: row.n_queries)
    references = [row for row in ordered if row.n_queries == reference_queries]
    if len(references) != 1:
        raise ValueError("reference query count must occur exactly once")
    threshold = references[0].d_opt_median_error * (1.0 + tolerance)
    d_pass = [row.n_queries for row in ordered if row.d_opt_median_error <= threshold]
    r_pass = [row.n_queries for row in ordered if row.random_median_error <= threshold]
    d_queries = min(d_pass) if d_pass else None
    r_queries = min(r_pass) if r_pass else None
    reduction = (
        float(1.0 - d_queries / r_queries)
        if d_queries is not None and r_queries is not None
        else None
    )
    return MatchedQueryCount(
        reference_queries=reference_queries,
        tolerance=tolerance,
        error_threshold=float(threshold),
        d_opt_queries=d_queries,
        random_queries=r_queries,
        d_opt_right_censored=d_queries is None,
        random_right_censored=r_queries is None,
        query_reduction=reduction,
    )


def residual_noise_scale(
    severities: np.ndarray, responses: np.ndarray, coefficients: np.ndarray
) -> float:
    """Root-mean-square pooled residual used by the frozen simulation."""

    y = np.asarray(responses, dtype=float)
    if y.ndim != 2:
        raise ValueError("responses must be source-by-probe")
    predicted = predict_surface(severities, coefficients)
    residual = y - predicted[None, :]
    return float(np.sqrt(np.mean(residual**2)))
