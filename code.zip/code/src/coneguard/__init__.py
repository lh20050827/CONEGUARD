"""ConeGuard core estimators and deterministic audio interventions."""

from .certificate import CertificateResult, certify_radius, fit_surface, predict_surface
from .design import d_optimal_design, quadratic_features
from .query_efficiency import EfficiencyAtSize, simulate_query_efficiency
from .reference_metrics import si_sdr

__all__ = [
    "CertificateResult",
    "EfficiencyAtSize",
    "certify_radius",
    "d_optimal_design",
    "fit_surface",
    "predict_surface",
    "quadratic_features",
    "simulate_query_efficiency",
    "si_sdr",
]
