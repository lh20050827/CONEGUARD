"""Deterministic design-criterion baselines for the quadratic probe space."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.stats import qmc

from .certificate import fit_surface, predict_surface
from .design import quadratic_features
from .query_efficiency import standardized_coefficient_error


@dataclass(frozen=True)
class FixedDesignSimulation:
    name: str
    median_error: float
    q90_error: float
    probability_better_than_d_opt: float | None


def _scaled_features(candidates: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    raw = quadratic_features(candidates)
    scale = raw.std(axis=0)
    scale[scale < 1e-12] = 1.0
    return raw / scale, scale


def _information_criterion(
    features: np.ndarray,
    selected: list[int],
    kind: str,
    ridge: float,
) -> float:
    matrix = features[np.asarray(selected, dtype=int)]
    gram = matrix.T @ matrix + ridge * np.eye(matrix.shape[1])
    inverse = np.linalg.inv(gram)
    if kind == "a_opt":
        return -float(np.trace(inverse))
    if kind == "g_opt":
        variances = np.einsum("ij,jk,ik->i", features, inverse, features)
        return -float(np.max(variances))
    raise ValueError(f"unknown design criterion: {kind}")


def exchange_optimal_design(
    candidates: np.ndarray,
    n_select: int,
    *,
    kind: str,
    ridge: float = 1e-9,
    max_exchange_passes: int = 20,
) -> np.ndarray:
    """Greedy A- or G-optimal selection followed by pairwise exchanges."""

    candidates = np.asarray(candidates, dtype=float)
    features, _ = _scaled_features(candidates)
    if n_select < features.shape[1] or n_select > len(candidates):
        raise ValueError("invalid design size")
    selected: list[int] = []
    remaining = set(range(len(candidates)))
    for _ in range(n_select):
        best = max(
            remaining,
            key=lambda index: (
                _information_criterion(
                    features, selected + [index], kind, ridge
                ),
                -index,
            ),
        )
        selected.append(best)
        remaining.remove(best)

    current = _information_criterion(features, selected, kind, ridge)
    for _ in range(max_exchange_passes):
        best_gain = 0.0
        best_swap: tuple[int, int, float] | None = None
        for position, _ in enumerate(selected):
            for new_index in sorted(remaining):
                proposal = selected.copy()
                proposal[position] = new_index
                value = _information_criterion(features, proposal, kind, ridge)
                gain = value - current
                if gain > best_gain + 1e-12:
                    best_gain = gain
                    best_swap = (position, new_index, value)
        if best_swap is None:
            break
        position, new_index, current = best_swap
        old_index = selected[position]
        selected[position] = new_index
        remaining.remove(new_index)
        remaining.add(old_index)
    return np.asarray(selected, dtype=int)


def maximin_design(candidates: np.ndarray, n_select: int) -> np.ndarray:
    """Select a deterministic Euclidean maximin design in action space."""

    candidates = np.asarray(candidates, dtype=float)
    if n_select < 1 or n_select > len(candidates):
        raise ValueError("invalid design size")
    first = int(np.argmax(np.linalg.norm(candidates, axis=1)))
    selected = [first]
    remaining = set(range(len(candidates))) - {first}
    distances = np.sum((candidates - candidates[first]) ** 2, axis=1)
    while len(selected) < n_select:
        best = max(remaining, key=lambda index: (distances[index], -index))
        selected.append(best)
        remaining.remove(best)
        distances = np.minimum(
            distances, np.sum((candidates - candidates[best]) ** 2, axis=1)
        )
    return np.asarray(selected, dtype=int)


def snapped_sobol_design(
    candidates: np.ndarray, n_select: int, *, seed: int
) -> np.ndarray:
    """Snap a scrambled Sobol sequence to unused grid candidates."""

    candidates = np.asarray(candidates, dtype=float)
    if n_select < 1 or n_select > len(candidates):
        raise ValueError("invalid design size")
    exponent = int(np.ceil(np.log2(max(2, 2 * n_select))))
    points = qmc.Sobol(d=candidates.shape[1], scramble=True, seed=seed).random_base2(
        exponent
    )
    selected: list[int] = []
    available = np.ones(len(candidates), dtype=bool)
    for point in points:
        distances = np.sum((candidates - point) ** 2, axis=1)
        distances[~available] = np.inf
        index = int(np.argmin(distances))
        selected.append(index)
        available[index] = False
        if len(selected) == n_select:
            break
    return np.asarray(selected, dtype=int)


def simulate_fixed_designs(
    candidates: np.ndarray,
    truth: np.ndarray,
    designs: dict[str, np.ndarray],
    *,
    noise_scale: float,
    n_sources: int = 32,
    repetitions: int = 1000,
    seed: int = 20260824,
    ridge: float = 1e-6,
) -> list[FixedDesignSimulation]:
    """Compare fixed 24-point designs under shared simulated observations."""

    candidates = np.asarray(candidates, dtype=float)
    truth = np.asarray(truth, dtype=float)
    features, feature_scale = _scaled_features(candidates)
    if truth.shape != (features.shape[1],):
        raise ValueError("truth dimension does not match candidates")
    if "d_opt" not in designs:
        raise ValueError("d_opt reference design is required")
    sizes = {len(np.asarray(indices)) for indices in designs.values()}
    if len(sizes) != 1:
        raise ValueError("all fixed designs must use the same number of queries")

    errors = {
        name: np.empty(repetitions, dtype=float) for name in [*designs, "random"]
    }
    true_response = predict_surface(candidates, truth)
    rng = np.random.default_rng(seed)
    n_select = sizes.pop()
    for repetition in range(repetitions):
        noise = rng.normal(0.0, noise_scale, size=(n_sources, len(candidates)))
        responses = true_response[None, :] + noise
        selected = dict(designs)
        selected["random"] = rng.choice(
            len(candidates), size=n_select, replace=False
        )
        for name, indices in selected.items():
            chosen = np.asarray(indices, dtype=int)
            estimate = fit_surface(
                candidates[chosen], responses[:, chosen], ridge=ridge
            )
            errors[name][repetition] = standardized_coefficient_error(
                estimate, truth, feature_scale
            )

    d_opt_errors = errors["d_opt"]
    return [
        FixedDesignSimulation(
            name=name,
            median_error=float(np.median(values)),
            q90_error=float(np.quantile(values, 0.9)),
            probability_better_than_d_opt=(
                None
                if name == "d_opt"
                else float(np.mean(values < d_opt_errors))
            ),
        )
        for name, values in errors.items()
    ]
