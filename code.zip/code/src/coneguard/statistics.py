"""Small deterministic statistical summaries used by evaluation scripts."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class BootstrapSummary:
    mean: float
    median: float
    ci_low: float
    ci_high: float
    n_sources: int
    draws: int


def cluster_bootstrap_mean(
    values: np.ndarray,
    *,
    draws: int = 10_000,
    alpha: float = 0.05,
    seed: int = 20260824,
) -> BootstrapSummary:
    """Summarize a one-dimensional source-level outcome by paired bootstrap."""

    observed = np.asarray(values, dtype=np.float64)
    if observed.ndim != 1 or observed.size < 2 or not np.all(np.isfinite(observed)):
        raise ValueError("values must be a finite vector with at least two sources")
    if draws < 100 or not 0.0 < alpha < 1.0:
        raise ValueError("invalid bootstrap configuration")
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, observed.size, size=(draws, observed.size))
    bootstrap_means = observed[indices].mean(axis=1)
    low, high = np.quantile(bootstrap_means, [alpha / 2.0, 1.0 - alpha / 2.0])
    return BootstrapSummary(
        mean=float(observed.mean()),
        median=float(np.median(observed)),
        ci_low=float(low),
        ci_high=float(high),
        n_sources=int(observed.size),
        draws=draws,
    )
