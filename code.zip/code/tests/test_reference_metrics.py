import numpy as np

from coneguard.reference_metrics import si_sdr


def test_si_sdr_prefers_clean_signal():
    rng = np.random.default_rng(3)
    reference = rng.normal(size=16000)
    clean = si_sdr(reference, reference)
    noisy = si_sdr(reference, reference + 0.2 * rng.normal(size=16000))
    assert clean > noisy + 20.0


def test_si_sdr_is_scale_invariant():
    rng = np.random.default_rng(4)
    reference = rng.normal(size=1000)
    assert si_sdr(reference, 2.0 * reference) > 100.0
