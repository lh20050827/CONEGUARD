import itertools

import numpy as np

from coneguard.design import FROZEN_4D_GRID_INDICES, d_optimal_design, quadratic_features


def test_quadratic_features_match_symmetric_form():
    u = np.array([0.2, 0.7])
    beta = np.array([-1.0, -2.0])
    hessian = np.array([[0.4, 0.3], [0.3, -0.2]])
    coefficients = np.array([*beta, hessian[0, 0], hessian[1, 1], hessian[0, 1]])
    observed = quadratic_features(u)[0] @ coefficients
    expected = beta @ u + 0.5 * u @ hessian @ u
    assert np.isclose(observed, expected)


def test_d_optimal_design_is_full_rank_and_deterministic():
    candidates = np.array(list(itertools.product([0.0, 0.5, 1.0], repeat=3)))[1:]
    first = d_optimal_design(candidates, 12)
    second = d_optimal_design(candidates, 12)
    assert first.rank == quadratic_features(candidates).shape[1]
    assert np.array_equal(first.indices, second.indices)
    assert np.isfinite(first.condition_number)


def test_canonical_design_uses_cross_platform_frozen_indices():
    candidates = np.asarray(
        list(itertools.product([0.0, 0.25, 0.5, 0.75, 1.0], repeat=4)), dtype=float
    )[1:]
    for size, expected in FROZEN_4D_GRID_INDICES.items():
        result = d_optimal_design(candidates, size)
        assert result.indices.tolist() == list(expected)
        assert result.rank == 14
    assert d_optimal_design(candidates, 24).condition_number <= 30.0
