import numpy as np

from coneguard.optimization import (
    INITIAL_POINTS,
    POOL_SIZE,
    expected_improvement,
    matern52_kernel,
    next_bayes_action,
    random_actions,
    select_incumbent,
    sobol_candidate_pool,
)


def test_sealed_actions_are_deterministic_and_bounded():
    first = sobol_candidate_pool()
    second = sobol_candidate_pool()
    np.testing.assert_array_equal(first, second)
    assert first.shape == (POOL_SIZE, 4)
    assert np.all((first >= 0.0) & (first <= 1.0))
    random = random_actions()
    assert random.shape == (40, 4)
    np.testing.assert_array_equal(random, random_actions())


def test_matern_kernel_and_expected_improvement_are_finite():
    actions = sobol_candidate_pool(size=16)[:INITIAL_POINTS]
    rewards = -np.sum((actions - 0.7) ** 2, axis=1)
    kernel = matern52_kernel(actions, actions)
    np.testing.assert_allclose(np.diag(kernel), 1.0)
    np.testing.assert_allclose(kernel, kernel.T)
    utility = expected_improvement(actions, rewards, sobol_candidate_pool(size=32))
    assert utility.shape == (32,)
    assert np.all(np.isfinite(utility))
    assert np.all(utility >= 0.0)


def test_bayes_queries_initial_order_then_no_duplicates():
    pool = sobol_candidate_pool(size=32)
    actions = []
    rewards = []
    indices = []
    for _ in range(12):
        index, action = next_bayes_action(
            np.asarray(actions).reshape(-1, 4), np.asarray(rewards), pool=pool
        )
        indices.append(index)
        actions.append(action)
        rewards.append(float(-np.sum((action - 0.4) ** 2)))
    assert indices[:INITIAL_POINTS] == list(range(INITIAL_POINTS))
    assert len(set(indices)) == len(indices)


def test_incumbent_retains_identity_without_positive_gain():
    actions = np.eye(4)
    incumbent = select_incumbent(actions, np.array([-1.0, -0.5, -0.2, 0.0]))
    np.testing.assert_array_equal(incumbent.action, np.zeros(4))
    assert incumbent.query_index is None
    positive = select_incumbent(actions, np.array([-1.0, 0.2, 0.1, -0.5]))
    np.testing.assert_array_equal(positive.action, actions[1])
    assert positive.reward == 0.2
