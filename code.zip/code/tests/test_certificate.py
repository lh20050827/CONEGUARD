import itertools

import numpy as np

from coneguard.certificate import certify_radius, fit_surface, worst_coordinate_derivatives
from coneguard.design import quadratic_features


def test_fit_recovers_quadratic_coefficients():
    u = np.array(list(itertools.product([0.0, 0.5, 1.0], repeat=2)))[1:]
    coefficients = np.array([-1.2, -0.8, 0.1, -0.2, 0.05])
    y = quadratic_features(u) @ coefficients
    observed = fit_surface(u, y, ridge=1e-12)
    assert np.allclose(observed, coefficients, atol=1e-7)


def test_worst_derivative_is_vertex_exact():
    coefficients = np.array([-1.0, -0.7, 0.4, -0.2, 0.3])
    observed = worst_coordinate_derivatives(coefficients, 2, 0.5)
    assert np.allclose(observed, [-1.0 + 0.5 * (0.4 + 0.3), -0.7 + 0.5 * 0.3])


def test_certificate_passes_strictly_monotone_surface():
    rng = np.random.default_rng(7)
    u = np.array(list(itertools.product([0.0, 0.5, 1.0], repeat=2)))[1:]
    coefficients = np.array([-1.2, -1.0, -0.2, -0.1, -0.05])
    mean = quadratic_features(u) @ coefficients
    responses = mean[None, :] + rng.normal(scale=0.01, size=(12, len(u)))
    result = certify_radius(u, responses, bootstrap_draws=200, radius_step=0.1)
    assert result.radius == 1.0
    assert result.simultaneous_upper[-1] < 0

