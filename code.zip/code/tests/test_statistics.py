import numpy as np

from coneguard.statistics import cluster_bootstrap_mean


def test_cluster_bootstrap_mean_is_deterministic_and_brackets_mean():
    values = np.linspace(-1.0, 2.0, 16)
    first = cluster_bootstrap_mean(values, draws=500, seed=9)
    second = cluster_bootstrap_mean(values, draws=500, seed=9)
    assert first == second
    assert first.ci_low < first.mean < first.ci_high
    assert first.n_sources == 16


def test_cluster_bootstrap_rejects_invalid_input():
    try:
        cluster_bootstrap_mean(np.array([1.0]))
    except ValueError:
        pass
    else:
        raise AssertionError("single-source bootstrap should fail")
