import numpy as np

from coneguard.design import quadratic_features
from coneguard.query_efficiency import (
    EfficiencyAtSize,
    matched_query_count,
    residual_noise_scale,
    simulate_query_efficiency,
    standardized_coefficient_error,
)


def test_standardized_coefficient_error_identity_and_shape_gate():
    truth = np.array([1.0, -2.0, 0.5])
    assert standardized_coefficient_error(truth, truth, np.ones(3)) == 0.0


def test_residual_noise_scale_zero_for_exact_surface():
    rng = np.random.default_rng(2)
    points = rng.uniform(size=(10, 2))
    coefficients = np.array([-1.0, -0.5, 0.2, 0.1, 0.05])
    responses = np.tile(quadratic_features(points) @ coefficients, (4, 1))
    assert residual_noise_scale(points, responses, coefficients) < 1e-12


def test_simulation_is_deterministic_and_finite():
    levels = np.linspace(0.0, 1.0, 5)
    candidates = np.array([(a, b) for a in levels for b in levels if a + b > 0])
    truth = np.array([-1.0, -0.8, 0.15, 0.10, 0.05])
    kwargs = dict(
        noise_scale=0.1,
        design_sizes=(5, 7),
        n_sources=4,
        repetitions=8,
        seed=9,
    )
    first = simulate_query_efficiency(candidates, truth, **kwargs)
    second = simulate_query_efficiency(candidates, truth, **kwargs)
    assert first == second
    assert all(np.isfinite(row.d_opt_median_error) for row in first)
    assert all(0.0 <= row.probability_d_opt_better <= 1.0 for row in first)


def test_matched_query_count_uses_relative_reference_tolerance():
    rows = [
        EfficiencyAtSize(14, 0.30, 0.60, 0.4, 0.8, 0.9),
        EfficiencyAtSize(24, 0.20, 0.35, 0.3, 0.5, 0.8),
        EfficiencyAtSize(32, 0.15, 0.21, 0.2, 0.3, 0.7),
    ]
    matched = matched_query_count(rows, tolerance=0.10)
    assert np.isclose(matched.error_threshold, 0.22)
    assert matched.d_opt_queries == 24
    assert matched.random_queries == 32
    assert matched.query_reduction == 0.25
