import itertools

import numpy as np

from coneguard.design import quadratic_features
from coneguard.design_baselines import (
    exchange_optimal_design,
    maximin_design,
    snapped_sobol_design,
)


def test_design_baselines_are_deterministic_and_unique():
    levels = (0.0, 0.5, 1.0)
    candidates = np.asarray(list(itertools.product(levels, repeat=4)), dtype=float)[
        1:
    ]
    methods = (
        lambda: exchange_optimal_design(
            candidates, 14, kind="a_opt", max_exchange_passes=0
        ),
        lambda: exchange_optimal_design(
            candidates, 14, kind="g_opt", max_exchange_passes=0
        ),
        lambda: maximin_design(candidates, 14),
        lambda: snapped_sobol_design(candidates, 14, seed=9),
    )
    for method in methods:
        first = method()
        second = method()
        assert np.array_equal(first, second)
        assert len(np.unique(first)) == 14


def test_space_filling_baselines_are_full_rank_at_formal_size():
    levels = (0.0, 0.25, 0.5, 0.75, 1.0)
    candidates = np.asarray(list(itertools.product(levels, repeat=4)), dtype=float)[
        1:
    ]
    for indices in (
        maximin_design(candidates, 24),
        snapped_sobol_design(candidates, 24, seed=20260824),
    ):
        assert np.linalg.matrix_rank(quadratic_features(candidates[indices])) == 14
