import numpy as np

from coneguard.dsp import apply_degradation_cone


def test_identity_is_deterministic_normalized_source():
    t = np.arange(16000) / 16000
    audio = 0.2 * np.sin(2 * np.pi * 440 * t)
    first = apply_degradation_cone(audio, np.zeros(4), source_id="a")
    second = apply_degradation_cone(audio, np.zeros(4), source_id="a")
    assert np.array_equal(first, second)
    assert first.shape == audio.shape


def test_axes_change_audio_and_are_deterministic():
    rng = np.random.default_rng(3)
    audio = rng.normal(scale=0.1, size=32000)
    identity = apply_degradation_cone(audio, np.zeros(4), source_id="b")
    for axis in range(4):
        severity = np.zeros(4)
        severity[axis] = 1.0
        changed = apply_degradation_cone(audio, severity, source_id="b")
        repeated = apply_degradation_cone(audio, severity, source_id="b")
        assert np.array_equal(changed, repeated)
        assert not np.allclose(changed, identity)

