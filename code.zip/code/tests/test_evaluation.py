import numpy as np

from coneguard.design import quadratic_features
from coneguard.evaluation import heldout_surface_metrics, order_antisymmetry_error


def test_heldout_surface_metrics_recovers_shared_quadratic():
    rng = np.random.default_rng(7)
    design = rng.uniform(size=(30, 4))
    heldout = rng.uniform(size=(12, 4))
    coefficients = rng.normal(size=14)
    design_y = np.tile(quadratic_features(design) @ coefficients, (5, 1))
    heldout_y = np.tile(quadratic_features(heldout) @ coefficients, (5, 1))
    metrics = heldout_surface_metrics(design, design_y, heldout, heldout_y)
    assert metrics.r2 > 0.999999
    assert metrics.mean_r2 > 0.999999
    assert metrics.rmse < 1e-5
    assert metrics.mean_rmse < 1e-5
    assert metrics.sign_error == 0.0
    assert metrics.mean_sign_error == 0.0


def test_mean_surface_metric_separates_source_heterogeneity():
    rng = np.random.default_rng(11)
    design = rng.uniform(size=(30, 4))
    heldout = rng.uniform(size=(16, 4))
    coefficients = rng.normal(size=14)
    design_mean = quadratic_features(design) @ coefficients
    heldout_mean = quadratic_features(heldout) @ coefficients
    source_offsets = np.linspace(-2.0, 2.0, 9)[:, None]
    design_y = design_mean[None, :] + source_offsets
    heldout_y = heldout_mean[None, :] + source_offsets
    metrics = heldout_surface_metrics(design, design_y, heldout, heldout_y)
    assert metrics.mean_r2 > 0.999999
    assert metrics.r2 < metrics.mean_r2
    assert metrics.between_source_rmse > 1.0


def test_order_antisymmetry_error():
    error = order_antisymmetry_error(np.array([2.0, -1.0]), np.array([-1.8, 1.1]))
    np.testing.assert_allclose(error, [0.2, 0.1])
